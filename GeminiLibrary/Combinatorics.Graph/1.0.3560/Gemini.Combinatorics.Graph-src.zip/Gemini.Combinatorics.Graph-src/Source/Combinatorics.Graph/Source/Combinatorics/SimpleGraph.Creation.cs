﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public static Graph FromText(StreamReader inputStream, int order)

		/// <summary>
		/// Loads a graph from a text stream.
		/// </summary>
		/// <param name="inputStream">The input source stream.</param>
		/// <param name="order">The order of the input graph.</param>
		/// <returns>The loaded graph.</returns>
		public static SimpleGraph FromText(StreamReader inputStream, int order)
		{
			SimpleGraph cGraph = new SimpleGraph();
			cGraph.Order = order;
			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			int nEdgeCount = 0;
			
			cGraph.MaxDegree = 0;
			cGraph.MinDegree = int.MaxValue;

			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(0);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif
				string strLine = inputStream.ReadLine();
				for (int j = 0; j < order; j++)
				{
					cGraph.AdjancecyMatrix[i].Add(strLine[j] - '0');

					if (cGraph.AdjancecyMatrix[i][j] != 0)
					{
						nEdgeCount++;

						cGraph.Degrees[i]++;
					}
				}
			}

			cGraph.EdgeCount = nEdgeCount / 2;

			return cGraph;
		}

		#endregion

		#region public static Graph FromAdjancecyMatrix(IList<IList<int>> adjancecyMatrix)

		/// <summary>
		/// Creates a <see cref="SimpleGraph"/> with a given adjancecy matrix.
		/// </summary>
		/// <param name="adjancecyMatrix">The adjancecy matrix of the creating graph.</param>
		/// <returns>A graph with the given adjancecy matrix.</returns>
		public static SimpleGraph FromAdjancecyMatrix(IList<IList<int>> adjancecyMatrix)
		{
			return FromAdjancecyMatrix(adjancecyMatrix, adjancecyMatrix.Count);
		}

		#endregion

		#region public static Graph FromAdjancecyMatrix(IList<IList<int>> adjancecyMatrix, int order)

		/// <summary>
		/// Creates a <see cref="SimpleGraph"/> with a given matrix containing its adjancecy matrix as the upper left part and the order of the graph.
		/// </summary>
		/// <param name="adjancecyMatrix">The adjancecy matrix of the creating graph.</param>
		/// <param name="order">The order of the graph</param>
		/// <returns>The created graph with the given order and adjancecy matrix.</returns>
		public static SimpleGraph FromAdjancecyMatrix(IList<IList<int>> adjancecyMatrix, int order)
		{
			SimpleGraph cGraph = new SimpleGraph();
			cGraph.Order = order;
			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			int nEdgeCount = 0;
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(0);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(adjancecyMatrix[i]));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(adjancecyMatrix[i]));
#endif
				foreach (int j in adjancecyMatrix[i])
				{
					if (j != 0)
					{
						nEdgeCount++;
						cGraph.Degrees[i]++;
					}
				}
			}
			cGraph.EdgeCount = nEdgeCount / 2;
			return cGraph;
		}

		#endregion

		#region public static Graph FromAdjancecyMatrix(int [,]adjancecyMatrix)

		/// <summary>
		/// Creates a <see cref="SimpleGraph"/> with a given adjancecy matrix.
		/// </summary>
		/// <param name="adjancecyMatrix">The adjancecy matrix of the creating graph.</param>
		/// <returns>A graph with the given adjancecy matrix.</returns>
		public static SimpleGraph FromAdjancecyMatrix(int[,] adjancecyMatrix)
		{
			return FromAdjancecyMatrix(adjancecyMatrix, adjancecyMatrix.GetLength(0));
		}

		#endregion

		#region public static Graph FromAdjancecyMatrix(int [,]adjancecyMatrix, int order)

		/// <summary>
		/// Creates a <see cref="SimpleGraph"/> with a given matrix containing its adjancecy matrix as the upper left part and the order of the graph.
		/// </summary>
		/// <param name="adjancecyMatrix">The adjancecy matrix of the creating graph.</param>
		/// <param name="order">The order of the graph</param>
		/// <returns>The created graph with the given order and adjancecy matrix.</returns>
		public static SimpleGraph FromAdjancecyMatrix(int[,] adjancecyMatrix, int order)
		{
			SimpleGraph cGraph = new SimpleGraph();
			cGraph.Order = order;
			cGraph.AdjancecyMatrix = new List<IList<int>>();
			cGraph.Degrees = new List<int>(order);
			int nEdgeCount = 0;
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(0);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif
				for (int j = 0; j < order; j++)
				{
					cGraph.AdjancecyMatrix[i].Add(adjancecyMatrix[i, j]);
					if (adjancecyMatrix[i, j] != 0)
					{
						nEdgeCount++;
						cGraph.Degrees[i]++;
					}
				}
			}
			cGraph.EdgeCount = nEdgeCount / 2;
			return cGraph;
		}

		#endregion

		#region public static Graph CompleteOfOrder(int order)

		/// <summary>
		/// Creates a complete graph of a given order.
		/// </summary>
		/// <param name="order">The order of the complete graph to be created.</param>
		/// <returns>The complete graph of the given order.</returns>
		public static SimpleGraph CompleteOfOrder(int order)
		{
			if (order < 1)
				throw new ArgumentOutOfRangeException("order");

			SimpleGraph cGraph = new SimpleGraph() { Order = order, EdgeCount = order * (order - 1) };

			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(order - 1);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif

				for (int j = 0; j < order; j++)
					cGraph.AdjancecyMatrix[i].Add(1);

				cGraph.AdjancecyMatrix[i][i] = 0;

				cGraph.Degrees[i] = order - 1;
			}
			return cGraph;
		}

		#endregion

		#region public static Graph CycleOfOrder(int order)

		/// <summary>
		/// Creates a cycle of a given order.
		/// </summary>
		/// <param name="order">The order of the cycle to be created.</param>
		/// <returns>The cycle of the given order.</returns>
		public static SimpleGraph CycleOfOrder(int order)
		{
			if (order < 1)
				throw new ArgumentOutOfRangeException("x_nOrder");

			SimpleGraph cGraph = new SimpleGraph() { Order = order, EdgeCount = order };

			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(2);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif

				for (int j = 0; j < order; j++)
					cGraph.AdjancecyMatrix[i].Add(0);
			}

			for (int i = 0; i < order; i++)
			{
				cGraph.AdjancecyMatrix[i][(i + 1) % order] = 1;
				cGraph.AdjancecyMatrix[(i + 1) % order][i] = 1;
			}
			return cGraph;
		}

		#endregion

		#region public static Graph StarOfOrder(int order)

		/// <summary>
		/// Creates a star graph of a given order.
		/// </summary>
		/// <param name="order">The order of the star to be created.</param>
		/// <returns>The star of the given order.</returns>
		public static SimpleGraph StarOfOrder(int order)
		{
			if (order < 1)
				throw new ArgumentOutOfRangeException("x_nOrder");

			SimpleGraph cGraph = new SimpleGraph() { Order = order, EdgeCount = order - 1, m_bIsTree = true };

			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(1);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif

				for (int j = 0; j < order; j++)
					cGraph.AdjancecyMatrix[i].Add(0);
			}

			for (int i = 1; i < order; i++)
			{
				cGraph.AdjancecyMatrix[0][i] = 1;
				cGraph.AdjancecyMatrix[i][0] = 1;
			}

			cGraph.Degrees[0] = order - 1;

			return cGraph;
		}

		#endregion

		#region public static Graph WheelOfOrder(int order)

		/// <summary>
		/// Creates a wheel of a given order.
		/// </summary>
		/// <param name="order">The order of the wheel to be created.</param>
		/// <returns>The wheel of the given order.</returns>
		public static SimpleGraph WheelOfOrder(int order)
		{
			if (order < 1)
				throw new ArgumentOutOfRangeException("order");

			SimpleGraph cGraph = new SimpleGraph() { Order = order };

			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);
			int nCycleVerticesDegress;
			switch (order)
			{
				case 1:
					cGraph.EdgeCount = 0;
					nCycleVerticesDegress = 0;
					break;
				case 2:
					cGraph.EdgeCount = 1;
					nCycleVerticesDegress = 1;
					break;
				case 3:
					cGraph.EdgeCount = 3;
					nCycleVerticesDegress = 2;
					break;
				default:
					cGraph.EdgeCount = 2 * order - 2;
					nCycleVerticesDegress = 3;
					break;
			}
			for (int i = 0; i < order; i++)
			{
				cGraph.Degrees.Add(nCycleVerticesDegress);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif

				for (int j = 0; j < order; j++)
					cGraph.AdjancecyMatrix[i].Add(0);
			}

			for (int i = 1; i < order; i++)
			{
				cGraph.AdjancecyMatrix[0][i] = 1;
				cGraph.AdjancecyMatrix[i][0] = 1;
			}

			for (int i = 1; i < order - 1; i++)
			{
				cGraph.AdjancecyMatrix[i][i + 1] = 1;
				cGraph.AdjancecyMatrix[i + 1][i] = 1;
			}

			if (order - 1 > 1)
			{
				cGraph.AdjancecyMatrix[order - 1][1] = 1;
				cGraph.AdjancecyMatrix[1][order - 1] = 1;
			}

			cGraph.Degrees[0] = order - 1;

			return cGraph;
		}

		#endregion

		#region public static Graph PathOfOrder(int order)

		/// <summary>
		/// Creates a path of a given order.
		/// </summary>
		/// <param name="order">The order of the path to be created.</param>
		/// <returns>The path of the given order.</returns>
		public static SimpleGraph PathOfOrder(int order)
		{
			if (order < 1)
				throw new ArgumentOutOfRangeException("order");

			SimpleGraph cGraph = new SimpleGraph() { Order = order, EdgeCount = order - 1, m_bIsTree = true };

			cGraph.AdjancecyMatrix = new List<IList<int>>(order);
			cGraph.Degrees = new List<int>(order);

			if (order > 1)
			{
				{
					cGraph.Degrees.Add(1);
#if DEBUG
					cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
					cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif
					for (int j = 0; j < order; j++)
						cGraph.AdjancecyMatrix[0].Add(0);

					cGraph.AdjancecyMatrix[0][1] = 1;
				}

				for (int i = 1; i < order - 1; i++)
				{
					cGraph.Degrees.Add(2);
#if DEBUG
					cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
					cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif

					for (int j = 0; j < order; j++)
						cGraph.AdjancecyMatrix[i].Add(0);

					cGraph.AdjancecyMatrix[i][i - 1] = 1;
					cGraph.AdjancecyMatrix[i][i + 1] = 1;
				}

				{
					cGraph.Degrees.Add(1);
#if DEBUG
					cGraph.AdjancecyMatrix.Add(new DebugableList<int>(order));
#else
					cGraph.AdjancecyMatrix.Add(new List<int>(order));
#endif
					for (int j = 0; j < order; j++)
						cGraph.AdjancecyMatrix[order - 1].Add(0);

					cGraph.AdjancecyMatrix[order - 1][order - 2] = 1;
				}
			}
			else
			{
				cGraph.Degrees.Add(0);
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(1));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(1));
#endif
				cGraph.AdjancecyMatrix[0].Add(0);
			}

			return cGraph;
		}

		#endregion

		/*
		public static Graph FromIntersectionArray(IList<int> x_lstBArray, IList<int> x_lstCArray, IList<int> x_lstLevelVertexCount)
		{
			int nVertexCount = x_lstLevelVertexCount.Sum();
			List<List<int>> lstAdjancecy = new List<IList<int>>(nVertexCount);
			for (int i = 0; i < nVertexCount; i++)
			{
				List<int> lstTemp = new List<int>(nVertexCount);
				for (int i = 0; i < nVertexCount; i++)
					lstTemp.Add(0);
				lstAdjancecy.Add(lstTemp);
			}

			int nLevelCount = x_lstLevelVertexCount.Count;
			int nCurPos = 1;
			for (int i = 1; i < nLevelCount - 1; i++)
			{
				int nCurCount = x_lstLevelVertexCount[i];
				int nPrevCount = x_lstLevelVertexCount[i - 1];
				int nFraction = nCurCount / nPrevCount;
				for (int j = 0; j < nCurCount; j++)
				{
					lstAdjancecy[nCurPos + j][nCurPos - nPrevCount + j * nFraction] = 1;
					lstAdjancecy[nCurPos - nPrevCount + j * nFraction][nCurPos + j] = 1;
				}
				nCurPos += nCurCount;
			}

			int nStart = nCurPos;
			while ((nCurPos >= nStart) && (nCurPos > nVertexCount))
			{
				// c_i -> prev
				// a_i -> current
				
			}
		}
		*/
	}
}
