﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public bool IsComplete

		/// <summary>
		/// Gets the value indicating whether the graph is complete or not.
		/// </summary>
		public bool IsComplete { get { return m_nEdgeCount == m_nOrder * (m_nOrder - 1) / 2; } }

		#endregion

		#region public bool IsEmpty

		/// <summary>
		/// Gets the value indicating whether the graph is empty or not.
		/// </summary>
		public bool IsEmpty { get { return EdgeCount == 0; } }

		#endregion

		#region public bool IsBipartite

		/// <summary>
		/// Gets the value indicating whether the graph is bipartite or not.
		/// </summary>
		public bool IsBipartite
		{
			get
			{
				lock (m_oIsBipartiteSynchronizer)
				{
					if (!m_nbIsBipartite.HasValue)
					{
						if (m_nChromaticNumber != -1)
						{
							if (ChromaticNumber < 2)
								m_nbIsBipartite = true;
							else
								m_nbIsBipartite = false;
						}
						else
						{
							LinkedList<int> lnkVisitingVertices = new LinkedList<int>();
#if DEBUG
							List<int> lstVertexColors = new DebugableList<int>(new int[Order]);
#else
							List<int> lstVertexColors = new List<int>(new int[Order]);
#endif
							int nMaxColor = 0;
							for (int i = 0; i < m_nOrder; i++)
							{
								int nCurVertex;
								int nCurColor;
								if (lnkVisitingVertices.Count == 0)
								{
									nCurVertex = lstVertexColors.FindIndex(c => c == 0);
									lstVertexColors[nCurVertex] = 1;
									nCurColor = 1;
								}
								else
								{
									nCurVertex = lnkVisitingVertices.First.Value;
									lnkVisitingVertices.RemoveFirst();
									nCurColor = lstVertexColors[nCurVertex];
								}

								foreach (int nNeighbour in this.GetNeighborsOf(nCurVertex))
								{
									if (lstVertexColors[nNeighbour] == 0)
									{
										lnkVisitingVertices.AddLast(nNeighbour);
										lstVertexColors[nNeighbour] = 3 - nCurColor;
									}
									else if (lstVertexColors[nNeighbour] == nCurColor)
									{
										m_nbIsBipartite = false;
										return false;
									}
								}

								if (nCurColor > nMaxColor)
									nMaxColor = nCurColor;
							}
							m_nbIsBipartite = true;
							m_nChromaticNumber = nMaxColor;
							m_lstVertexColors = new List<int>(lstVertexColors);
						}
					}
				}

				return (m_nbIsBipartite == true);
			}
			protected set
			{
				lock (m_oIsBipartiteSynchronizer)
				{
					m_nbIsBipartite = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIsBipartiteSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool? m_nbIsBipartite;

		#endregion

		#region public bool IsRegular

		/// <summary>
		/// Gets the value indicating whether the graph is regular or not.
		/// </summary>
		public bool IsRegular
		{
			get
			{
				lock (m_oIsRegularSynchronizer)
				{
					if (!m_nbIsRegular.HasValue)
					{
						m_nbIsRegular = true;

						if (Order > 0)
						{
							int k = Degrees[0];
							foreach (int d in Degrees)
							{
								if (k != d)
								{
									m_nbIsRegular = false;
									break;
								}
							}
						}
					}

					return m_nbIsRegular.Value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIsRegularSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool? m_nbIsRegular;

		#endregion

		#region public bool IsTraingleFree

		/// <summary>
		/// Gets the value indicating whether the graph is traingle-free or not.
		/// </summary>
		public bool IsTraingleFree
		{
			get
			{
				lock (m_oIsTraingleFreeSynchronizer)
				{
					if (!m_nbIsTraingleFree.HasValue)
					{
						m_nbIsTraingleFree = true;

						for (int i = 0; i < m_nOrder; i++)
						{
							for (int j = i + 1; j < m_nOrder; j++)
							{
								for (int k = j + 1; k < m_nOrder; k++)
								{
									if ((AdjancecyMatrix[i][j] == 1) &&
										(AdjancecyMatrix[j][k] == 1) &&
										(AdjancecyMatrix[k][i] == 1))
									{
										return false;
									}
								}
							}
						}
					}
					
					return true;
				}
			}
			protected set
			{
				lock (m_oIsTraingleFreeSynchronizer)
				{
					m_nbIsTraingleFree = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIsTraingleFreeSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool? m_nbIsTraingleFree;

		#endregion
	}
}
