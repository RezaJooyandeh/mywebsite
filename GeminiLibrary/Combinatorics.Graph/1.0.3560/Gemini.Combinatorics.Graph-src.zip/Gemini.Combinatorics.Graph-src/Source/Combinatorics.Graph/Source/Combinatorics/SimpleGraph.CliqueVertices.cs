﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using System.Collections.ObjectModel;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		class CliqueVertices : IEnumerable<ICollection<int>>
		{
			#region .ctor

			public CliqueVertices(SimpleGraph x_cGraph)
			{
				if (x_cGraph == null)
					throw new ArgumentNullException("x_cGraph");

				m_cGraph = x_cGraph;
			}

			#endregion

			#region IEnumerable<ICollection<int>> Members

			public IEnumerator<ICollection<int>> GetEnumerator()
			{
				return new CliqueEnumerator(m_cGraph);
			}

			#endregion

			#region IEnumerable Members

			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}

			#endregion

			#region class CliqueEnumerator

			class CliqueEnumerator : IEnumerator<ICollection<int>>
			{
				#region .ctor

				public CliqueEnumerator(SimpleGraph graph)
				{
					if (graph == null)
						throw new ArgumentNullException("graph");

					this.graph = graph;
					states = new VertexIsInClique[graph.Order];
					pos = graph.Order - 1;
				}

				#endregion

				#region IEnumerator<ICollection<int>> Members

				public ICollection<int> Current
				{
					get
					{
						if (readonlyCurrent == null)
							throw new InvalidOperationException();

						return readonlyCurrent;
					}
					private set
					{
						if (value != null)
						{
							current = (IList<int>)value;
#if DEBUG
							readonlyCurrent = new DebugableReadOnlyList<int>(current);
#else
							readonlyCurrent = new ReadOnlyCollection<int>(current);
#endif
						}
						else
						{
							current = null;
							readonlyCurrent = null;
						}
					}
				}

				#endregion

				#region IDisposable Members

				public void Dispose()
				{
					graph = null;
					states = null;
				}

				#endregion

				#region IEnumerator Members

				object IEnumerator.Current
				{
					get { return Current; }
				}

				public bool MoveNext()
				{
					int nVertexCount = graph.Order;

					while (true)
					{
						if (pos == nVertexCount)
						{
							Current = null;
							return false;
						}

						if (states[pos] == VertexIsInClique.Yes)
						{
							states[pos] = VertexIsInClique.NotYet;
							pos++;
							continue;
						}
						else if (states[pos] == VertexIsInClique.NotYet)
							states[pos] = VertexIsInClique.No;
						else if (states[pos] == VertexIsInClique.No)
						{
							states[pos] = VertexIsInClique.Yes;
							bool bCanBeInClique = true;
							for (int i = pos + 1; i < nVertexCount; i++)
							{
								if ((states[i] == VertexIsInClique.Yes) && (graph.AdjancecyMatrix[pos][i] == 0))
								{
									bCanBeInClique = false;
									break;
								}
							}

							if (!bCanBeInClique)
							{
								states[pos] = VertexIsInClique.NotYet;
								pos++;
								continue;
							}
						}

						if (pos == 0)
						{
							Current = new List<int>(nVertexCount);
							for (int i = 0; i < nVertexCount; i++)
							{
								if (states[i] == VertexIsInClique.Yes)
									current.Add(i);
							}
							if (Current.Count > 0)
								return true;
						}
						else
							pos--;
					}
				}

				public void Reset()
				{
					int nVertexCount = graph.Order;
					for (int i = pos; i < nVertexCount; i++)
						states[i] = VertexIsInClique.NotYet;

					pos = nVertexCount - 1;
					Current = null;
				}

				#endregion

				private VertexIsInClique[] states;
				private int pos;
				private SimpleGraph graph;
				private IList<int> current;
#if DEBUG
				private DebugableReadOnlyList<int> readonlyCurrent;
#else
				private ReadOnlyCollection<int> readonlyCurrent;
#endif
			}

			#endregion

			#region enum VertexIsInClique

			enum VertexIsInClique
			{
				NotYet,
				No,
				Yes
			}

			#endregion

			private SimpleGraph m_cGraph;
		}
	}
}
