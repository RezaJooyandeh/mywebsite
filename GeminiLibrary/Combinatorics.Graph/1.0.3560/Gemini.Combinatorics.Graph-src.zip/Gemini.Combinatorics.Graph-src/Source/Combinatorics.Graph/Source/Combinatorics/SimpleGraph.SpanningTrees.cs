﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;

namespace Gemini.Combinatorics
{
	/*
	partial class SimpleGraph
	{
		class SpanninTrees : IEnumerable<Tree>
		{
			public SpanninTrees(SimpleGraph x_cGraph)
			{
				MainGraph = x_cGraph;
			}

			#region IEnumerable<Tree> Members

			public IEnumerator<Tree> GetEnumerator()
			{
				//*/
				/*
				if (MainGraph.IsConnected)
				{
					int nTotalEdgeCount = MainGraph.EdgeCount;
					EdgeIsInTree[] arrEdgesState = new EdgeIsInTree[nTotalEdgeCount];
					Dictionary<int, bool> setSelectedVertices = new Dictionary<int, bool>(MainGraph.Order);

					int nCurPos = 0;
					int nSelectedEdgeCount = 0;
					while (true)
					{
						Edge cCurrentEdge = MainGraph.Edges[nCurPos];
						bool bV1AlreadyAdded = setSelectedVertices.ContainsKey(cCurrentEdge.V1);
						bool bV2AlreadyAdded = setSelectedVertices.ContainsKey(cCurrentEdge.V2);
						if ((bV1AlreadyAdded || bV2AlreadyAdded) && !(bV1AlreadyAdded && bV2AlreadyAdded))
						{
							arrEdgesState[nCurPos] = EdgeIsInTree.Yes;
							nSelectedEdgeCount++;

							if (!bV1AlreadyAdded)
								setSelectedVertices.Add(cCurrentEdge.V1, true);
							else
								setSelectedVertices.Add(cCurrentEdge.V2, true);
						}
					}
				}

				return null;
				//*/
/*
				throw new NotImplementedException();
			}

			#endregion

			#region IEnumerable Members

			IEnumerator IEnumerable.GetEnumerator()
			{
				return GetEnumerator();
			}

			#endregion

			public SimpleGraph MainGraph { get; private set; }

			#region EdgeIsInTree

			enum EdgeIsInTree
			{
				NotYet,
				No,
				Yes
			}

			#endregion
		}
	}
	//*/
}
