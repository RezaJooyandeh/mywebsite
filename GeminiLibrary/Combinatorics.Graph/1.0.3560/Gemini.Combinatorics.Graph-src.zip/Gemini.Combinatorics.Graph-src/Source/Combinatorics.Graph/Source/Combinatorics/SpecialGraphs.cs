﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	public static class SpecialGraphs
	{
		#region public static Graph Peterson

		/// <summary>
		/// Gets the Peterson graph.
		/// </summary>
		public static SimpleGraph Peterson
		{
			get
			{
				lock (m_oPetersonSynchronizer)
				{
					if (m_cPeterson == null)
					{
						int [,] adjancecy = new int[,]
						{
							{ 0, 1, 0, 0, 1, 1, 0, 0, 0, 0 },
							{ 1, 0, 1, 0, 0, 0, 1, 0, 0, 0 },
							{ 0, 1, 0, 1, 0, 0, 0, 1, 0, 0 },
							{ 0, 0, 1, 0, 1, 0, 0, 0, 1, 0 },
							{ 1, 0, 0, 1, 0, 0, 0, 0, 0, 1 },

							{ 1, 0, 0, 0, 0, 0, 0, 1, 1, 0 },
							{ 0, 1, 0, 0, 0, 0, 0, 0, 1, 1 },
							{ 0, 0, 1, 0, 0, 1, 0, 0, 0, 1 },
							{ 0, 0, 0, 1, 0, 1, 1, 0, 0, 0 },
							{ 0, 0, 0, 0, 1, 0, 1, 1, 0, 0 }
						};

						m_cPeterson = SimpleGraph.FromAdjancecyMatrix(adjancecy);
					}

					return m_cPeterson;
				}
			}
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static object m_oPetersonSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private static SimpleGraph m_cPeterson;

		#endregion
	}
}
