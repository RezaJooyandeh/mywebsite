﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		/// <summary>
		/// Create a graph which is the cartesian product of two graphs.
		/// </summary>
		/// <param name="leftOperandGraph">The left operand of the production.</param>
		/// <param name="rightOperandGraph">The right operand of the production.</param>
		/// <returns>The cartesian product of <paramref name="leftOperandGraph"/> and <paramref name="rightOperandGraph"/></returns>
		public static SimpleGraph CartesianProduct(SimpleGraph leftOperandGraph, SimpleGraph rightOperandGraph)
		{
			int nLeftOrder = leftOperandGraph.Order;
			int nRightOrder = rightOperandGraph.Order;
			int nOrder = nLeftOrder * nRightOrder;
			int [,]arrAdjancecy = new int[nOrder, nOrder];

			for (int i = 0; i < nLeftOrder; i++)
			{
				foreach (Edge e in rightOperandGraph.Edges)
				{
					arrAdjancecy[i + e.V1 * nLeftOrder, i + e.V2 * nLeftOrder] = 1;
					arrAdjancecy[i + e.V2 * nLeftOrder, i + e.V1 * nLeftOrder] = 1;
				}
			}

			for (int i = 0; i < nRightOrder; i++)
			{
				foreach (Edge e in leftOperandGraph.Edges)
				{
					arrAdjancecy[e.V1 + i * nLeftOrder, e.V2 + i * nLeftOrder] = 1;
					arrAdjancecy[e.V2 + i * nLeftOrder, e.V1 + i * nLeftOrder] = 1;
				}
			}

			return SimpleGraph.FromAdjancecyMatrix(arrAdjancecy);
		}

		/// <summary>
		/// Create a graph which is the disjoint union of two graphs.
		/// </summary>
		/// <param name="leftOperandGraph">The left operand of the production.</param>
		/// <param name="rightOperandGraph">The right operand of the production.</param>
		/// <returns>The disjoint union of <paramref name="leftOperandGraph"/> and <paramref name="rightOperandGraph"/></returns>
		public static SimpleGraph DisjointUnion(SimpleGraph leftOperandGraph, SimpleGraph rightOperandGraph)
		{
			int nLeftOrder = leftOperandGraph.Order;
			int nRightOrder = rightOperandGraph.Order;
			int nOrder = nLeftOrder + nRightOrder;
			int[,] arrAdjancecy = new int[nOrder, nOrder];

			foreach (Edge e in leftOperandGraph.Edges)
			{
				arrAdjancecy[e.V1, e.V2] = 1;
				arrAdjancecy[e.V2, e.V1] = 1;
			}

			foreach (Edge e in rightOperandGraph.Edges)
			{
				arrAdjancecy[e.V1 + nLeftOrder, e.V2 + nLeftOrder] = 1;
				arrAdjancecy[e.V2 + nLeftOrder, e.V1 + nLeftOrder] = 1;
			}

			return SimpleGraph.FromAdjancecyMatrix(arrAdjancecy);
		}
	}
}
