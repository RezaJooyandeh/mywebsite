﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region IsTree

		/// <summary>
		/// Gets the value indicating if the graph is a tree.
		/// </summary>
		public bool IsTree
		{
			get
			{
				lock (m_oIsTreeSynchronizer)
				{
					if (!m_bIsTree.HasValue)
					{
						if (IsConnected && (EdgeCount == Order - 1))
						{
							m_bIsTree = true;
							m_nChromaticNumber = (Order == 1) ? 1 : 2;
							m_nbIsBipartite = true;
						}
						else
							m_bIsTree = false;
					}

					return m_bIsTree.Value;
				}
			}
			protected set
			{
				lock (m_oIsTreeSynchronizer)
				{
					m_bIsTree = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIsTreeSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool? m_bIsTree;

		#endregion

		/*
		#region SpanningTrees
		public ICollection<Tree> SpanningTrees
		{
			get
			{
				lock (m_oSpanningTreesSynchronizer)
				{
					if (m_colSpanningTrees == null)
						throw new NotImplementedException();

					return m_colSpanningTrees;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oSpanningTreesSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ICollection<Tree> m_colSpanningTrees;

		#endregion
		//*/
	}
}
