﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		/// <summary>
		/// Gets an enumerator which iterates cliques of graphs.
		/// </summary>
		public IEnumerable<ICollection<int>> CliquesVertices
		{
			get { return new CliqueVertices(this); }
		}

		/// <summary>
		/// Gets an enumerator which iterates cocliques of graphs.
		/// </summary>
		public IEnumerable<ICollection<int>> CoCliquesVertices
		{
			get { return Complement.CliquesVertices; }
		}
	}
}
