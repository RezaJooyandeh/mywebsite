﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	public static class SimpleGraphExtensions
	{
		/// <summary>
		/// Produces an isomorph graph to the input graph whose vertices order are specfied by a bfs search.
		/// </summary>
		/// <param name="self">The input graph.</param>
		/// <returns>An isomorph graph to the input graph whose vertices order are specfied by a bfs search.</returns>
		public static SimpleGraph SortVerticesWithBFS(this SimpleGraph self)
		{
			List<int> lstLabels = new List<int>(self.Order);
			lstLabels.AddRange(self.GetComponentIndexes(0));
			List<int> lstVisiteds = new List<int>(self.Order);
			for (int i = 0; i < self.Order; i++)
			{
				if (lstLabels.Contains(i))
					lstVisiteds.Add(-1);
				else
					lstVisiteds.Add(i);
			}

			while (lstLabels.Count < self.Order)
			{
				IList<int> lstCurrentComponent = self.GetComponentIndexes(lstVisiteds.First(i => i != -1));
				foreach (int i in lstCurrentComponent)
					lstVisiteds[i] = -1;

				lstLabels.AddRange(lstCurrentComponent);
			}
	
			return self.Relable(lstLabels.ToArray());
		}

		/// <summary>
		/// Produces an isomorph graph to the input graph whose vertices are in a given order.
		/// </summary>
		/// <param name="self">The input graph.</param>
		/// <param name="newLables">The ordered vertices.</param>
		/// <returns>An isomorph graph to the input graph whose vertices are in a given order.</returns>
		public static SimpleGraph Relable(this SimpleGraph self, int []newLables)
		{
			int[,] arrNewAdj = new int[self.Order, self.Order];
			for (int i = 0; i < self.Order; i++)
			{
				for (int j = 0; j < self.Order; j++)
					arrNewAdj[i, j] = self.AdjancecyMatrix[newLables[i]][newLables[j]];						
			}

			return SimpleGraph.FromAdjancecyMatrix(arrNewAdj, self.Order);
		}

		/// <summary>
		/// Writes the adjancecy matrix into a given <see cref="TextWriter"/>.
		/// </summary>
		/// <param name="self">The graph to be written.</param>
		/// <param name="output">The output stream.</param>
		public static void WriteAdjancecy(this SimpleGraph self, TextWriter output)
		{
			for (int i = 0; i < self.Order; i++)
			{
				for (int j = 0; j < self.Order; j++)
					output.Write("{0,2}", self.AdjancecyMatrix[i][j]);
				output.WriteLine();
			}
		}

		/// <summary>
		/// Gets the neighbors of a given vertex.
		/// </summary>
		/// <param name="self">The input graph.</param>
		/// <param name="vertexIndex">The index of the vertex whose neighbors are computing.</param>
		/// <returns>The neighbors of the <paramref name="vertexIndex"/> vertex.</returns>
		public static IEnumerable<int> GetNeighborsOf(this SimpleGraph self, int vertexIndex)
		{
			IList<int> adjVal = self.AdjancecyMatrix[vertexIndex];
			for (int i = 0; i < self.Order; i++)
			{
				if (adjVal[i] != 0)
					yield return i;
			}
		}

		/// <summary>
		/// Produces a graph with respect to a given graph by splitting each edge a number of edges.
		/// </summary>
		/// <param name="self">The input graph.</param>
		/// <param name="splitCount">The number which each edge should split into.</param>
		/// <returns>A graph with respect to a given graph by splitting each edge a number of edges.</returns>
		public static SimpleGraph SplitEdges(this SimpleGraph self, int splitCount)
		{
			if (splitCount < 1)
				throw new ArgumentOutOfRangeException("splitCount");
			if (splitCount == 1)
				return (SimpleGraph)self.Clone();
			SimpleGraph cGraph = new SimpleGraph();
			cGraph.Order = self.Order + self.EdgeCount * (splitCount - 1);
			cGraph.AdjancecyMatrix = new List<IList<int>>(cGraph.Order);
			for (int i = 0; i < cGraph.Order; i++)
			{
#if DEBUG
				List<int> lstTemp = new DebugableList<int>(cGraph.Order);
#else
				List<int> lstTemp = new List<int>(cGraph.Order);
#endif
				cGraph.AdjancecyMatrix.Add(lstTemp);
				for (int j = 0; j < cGraph.Order; j++)
					lstTemp.Add(0);
			}

			int nSplitterVertex = self.Order;
			foreach (Edge sEdge in self.Edges)
			{
				cGraph.AdjancecyMatrix[sEdge.V1][nSplitterVertex] = 1;
				cGraph.AdjancecyMatrix[nSplitterVertex][sEdge.V1] = 1;
				for (int i = 2; i < splitCount; i++)
				{
					cGraph.AdjancecyMatrix[nSplitterVertex][nSplitterVertex + 1] = 1;
					cGraph.AdjancecyMatrix[nSplitterVertex + 1][nSplitterVertex] = 1;
					nSplitterVertex++;
				}
				cGraph.AdjancecyMatrix[nSplitterVertex][sEdge.V2] = 1;
				cGraph.AdjancecyMatrix[sEdge.V2][nSplitterVertex] = 1;
				nSplitterVertex++;
			}

			cGraph.EdgeCount = self.EdgeCount * splitCount;

			return cGraph;
		}
	}
}
