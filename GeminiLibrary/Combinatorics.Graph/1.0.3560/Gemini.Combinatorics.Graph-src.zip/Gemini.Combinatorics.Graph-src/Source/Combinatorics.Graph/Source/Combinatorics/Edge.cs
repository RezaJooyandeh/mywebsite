﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	/// <summary>
	/// Specifies an edge between to vertex.
	/// </summary>
	[DebuggerDisplay("{ToString()}")]
	public struct Edge : IEquatable<Edge>
	{
		/// <summary>
		/// Constructs a new instance of <see cref="Edge"/> between two given vertex.
		/// </summary>
		/// <param name="x_nV1">The index of the first vertex.</param>
		/// <param name="x_nV2">The index of the second vertex.</param>
		public Edge(int x_nV1, int x_nV2)
		{
			m_nV1 = x_nV1;
			m_nV2 = x_nV2;
		}

		/// <summary>
		/// Gets the index of the first vertex.
		/// </summary>
		public int V1
		{
			get { return m_nV1; }
			set { m_nV1 = value; }
		}

		/// <summary>
		/// Gets the index of the second vertex.
		/// </summary>
		public int V2
		{
			get { return m_nV2; }
			set { m_nV2 = value; }
		}

		/// <summary>
		/// Determines whether the specified <see cref="System.Object"/> is equal to the current <see cref="Edge"/>.
		/// </summary>
		/// <param name="x_oOther">The <see cref="System.Object"/> to compare with the current <see cref="Edge"/>.</param>
		/// <returns>true if the specified <see cref="System.Object"/> is equal to the current <see cref="Edge"/>; otherwise, false.</returns>
		public override bool Equals(object x_oOther)
		{
			if (x_oOther == null || GetType() != x_oOther.GetType())
				return false;

			Edge sOther = (Edge)x_oOther;

			return Equals(sOther);
		}

		/// <summary>
		/// Serves as a hash function for an <see cref="Edge"/>. 
		/// </summary>
		/// <returns>A hash code for the current <see cref="Edge"/>.</returns>
		public override int GetHashCode()
		{
			return m_nV1 ^ m_nV2;
		}

		/// <summary>
		/// Returns a <see cref="System.String"/> that represents the current <see cref="Edge"/>.
		/// </summary>
		/// <returns>A <see cref="System.String"/> that represents the current <see cref="Edge"/>.</returns>
		public override string ToString()
		{
			return string.Format("[{0}-{1}]", V1, V2);
		}

		#region IEquatable<Edge> Members

		/// <summary>
		/// Indicates whether the current <see cref="Edge"/> is equal to another <see cref="Edge"/> of the same type.
		/// </summary>
		/// <param name="x_sOther">An <see cref="Edge"/> to compare with this <see cref="Edge"/>.</param>
		/// <returns></returns>
		public bool Equals(Edge x_sOther)
		{
			return	((x_sOther.V1 == m_nV1) && (x_sOther.V2 == m_nV2)) ||
					((x_sOther.V1 == m_nV2) && (x_sOther.V2 == m_nV1));
		}

		#endregion

		/// <summary>
		/// Indicates if an edge is adjacent to this edge.
		/// </summary>
		/// <param name="edge"></param>
		/// <returns></returns>
		public bool IsAdjacent(Edge edge)
		{
			return ((m_nV1 == edge.m_nV1) && (m_nV2 != edge.m_nV2)) ||
				   ((m_nV1 != edge.m_nV1) && (m_nV2 == edge.m_nV2)) ||
				   ((m_nV1 == edge.m_nV2) && (m_nV2 != edge.m_nV1)) ||
				   ((m_nV1 != edge.m_nV2) && (m_nV2 == edge.m_nV1));
		}

		/// <summary>
		/// Indicates if an edge lies on a vertex or not.
		/// </summary>
		/// <param name="vertex"></param>
		/// <returns></returns>
		public bool LiesOn(int vertex)
		{
			return (vertex == m_nV1) || (vertex == m_nV2);
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nV1;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nV2;
	}
}
