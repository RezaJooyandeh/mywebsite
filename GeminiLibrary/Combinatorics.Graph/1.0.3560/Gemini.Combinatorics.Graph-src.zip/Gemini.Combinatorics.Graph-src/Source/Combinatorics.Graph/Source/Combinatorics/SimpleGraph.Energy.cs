﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public double Energy

		/// <summary>
		/// Gets the energy of the graph.
		/// </summary>
		public double Energy
		{
			get
			{
				if (double.IsNaN(m_dEnergey))
					m_dEnergey = AdjancecyEigenvalues.Sum(e => (e >= 0) ? e : -e);

				return m_dEnergey;
			}
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private double m_dEnergey = double.NaN;

		#endregion

		#region public double IncidenceEnergy

		/// <summary>
		/// Gets the incidence energy of a graph.
		/// </summary>
		public double IncidenceEnergy
		{
			get
			{
				if (double.IsNaN(m_dIncidenceEnergey))
					m_dIncidenceEnergey = IncidenceSingularValues.Sum();

				return m_dIncidenceEnergey;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private double m_dIncidenceEnergey = double.NaN;

		#endregion

		#region public double LaplacianEnergy

		/// <summary>
		/// Gets the laplacian energy of the graph.
		/// </summary>
		public double LaplacianEnergy
		{
			get
			{
				if (double.IsNaN(m_dLaplacianEnergey))
				{
					double c = 2.0 * EdgeCount / Order;
					m_dLaplacianEnergey = LaplacianEigenvalues.Sum(e => Math.Abs(e - c));
				}

				return m_dLaplacianEnergey;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private double m_dLaplacianEnergey = double.NaN;

		#endregion

		#region public double LaplacianMatrixEnergy

		/// <summary>
		/// Gets the energy of the laplacian matrix of the graph.
		/// </summary>
		public double LaplacianMatrixEnergy
		{
			get
			{
				if (double.IsNaN(m_dLaplacianMatrixEnergey))
					m_dLaplacianMatrixEnergey = LaplacianEigenvalues.Sum(e => Math.Sqrt(Math.Abs(e)));

				return m_dLaplacianMatrixEnergey;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private double m_dLaplacianMatrixEnergey = double.NaN;

		#endregion
	}
}
