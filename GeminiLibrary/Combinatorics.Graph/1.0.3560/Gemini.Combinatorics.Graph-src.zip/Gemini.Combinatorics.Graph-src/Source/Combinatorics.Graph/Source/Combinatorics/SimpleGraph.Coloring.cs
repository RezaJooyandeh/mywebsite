﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public int ChromaticNumber

		/// <summary>
		/// Gets the chormatic number of the graph.
		/// </summary>
		public int ChromaticNumber
		{
			get
			{
				lock (m_oChromaticNumberSynchronizer)
				{
					if (m_nChromaticNumber == -1)
						ColorizeVertices();
				}

				return m_nChromaticNumber;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nChromaticNumber = -1;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nMinNonBipartiteChromaticNumber = 3;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oChromaticNumberSynchronizer = new object();

		#endregion

		#region public int EdgeChromaticNumber

		/// <summary>
		/// Gets the edge chromatic number of the graph.
		/// </summary>
		public int EdgeChromaticNumber
		{
			get { return LineGraph.ChromaticNumber; }
		}

		#endregion

		#region public IList<int> VertexColors

		/// <summary>
		/// Gets a candidate coloring for the verices of the graph with for its chromatic number.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(VertexColors)}")]
		public IList<int> VertexColors
		{
			get
			{
				lock (m_oVertexColorsSynchronizer)
				{
					if (m_nChromaticNumber == -1)
						ColorizeVertices();
				}

				return m_lstVertexColors;
			}
			private set { m_lstVertexColors = value; }
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private IList<int> m_lstVertexColors;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oVertexColorsSynchronizer = new object();

		#endregion

		#region public IList<int> GetBrelazColoring()

		/// <summary>
		/// Gets the brelaz coloring of the graph.
		/// </summary>
		/// <returns></returns>
		public IList<int> GetBrelazColoring()
		{
			int[] arrCd = new int[Order];
			int[] arrColor = new int[Order];
			for (int i = 0; i < m_nOrder; i++)
			{
				arrCd[i] = 0;
				arrColor[i] = 0;
			}

			for (int m = 0; m >= 0; )
			{
				int nCurNode = -1;
				for (int i = 0; i < m_nOrder; i++)
				{
					if (arrCd[i] != m)
						continue;
					nCurNode = i;
					break;
				}

				List<int> lstNeighbourColors = new List<int>(Order);
				foreach (int n in this.GetNeighborsOf(nCurNode))
					lstNeighbourColors.Add(arrColor[n]);

				lstNeighbourColors.Sort();
				int nMaxColor = 1;
				int nNeighboursCount = lstNeighbourColors.Count;
				if (nNeighboursCount != 0)
					nMaxColor = lstNeighbourColors[nNeighboursCount - 1] + 1;

				for (int i = 1; i <= nMaxColor; i++)
				{
					int nResult = lstNeighbourColors.BinarySearch(i);
					if ((nResult < 0) || (nResult >= nNeighboursCount))
					{
						arrColor[nCurNode] = i;
						break;
					}
				}

				arrCd[nCurNode] = -2 * Order;
				foreach (int n in this.GetNeighborsOf(nCurNode))
					arrCd[n]++;

				m = int.MinValue;
				for (int i = 0; i < m_nOrder; i++)
					if (arrCd[i] > m)
						m = arrCd[i];
			}

			return new List<int>(arrColor);
		}

		#endregion

		#region public bool CanColorizeVerticesWith(int maxColor, out IList<int> verticesColor, out int lastColoredVertex)

		/// <summary>
		/// Specifies if the graph can be colorized with a given number of colors.
		/// </summary>
		/// <param name="maxColor">Maximum number of different colors.</param>
		/// <param name="verticesColor">The colors of the verices.</param>
		/// <param name="lastColoredVertex">The index of the last colored vertices.</param>
		/// <returns>true if whole the grah can be colored with the given number of colors; false otherwise.</returns>
		public bool CanColorizeVerticesWith(int maxColor, out IList<int> verticesColor, out int lastColoredVertex)
		{
			verticesColor = new List<int>();
			int nCurVertex = 0;
			return CanColorizeVerticesWith(maxColor, ref verticesColor, out lastColoredVertex, ref nCurVertex);
		}

		#endregion

		#region public bool CanColorizeVerticesWith(int maxColor, ref IList<int> verticesColor, out int lastColoredVertex, ref int curVertex)

		/// <summary>
		/// Specifies if the graph can be colorized with a given number of colors.
		/// </summary>
		/// <param name="maxColor">Maximum number of different colors.</param>
		/// <param name="verticesColor">The colors of the verices.</param>
		/// <param name="curVertex">The index of the vertex which coloring should start from. The color of the previous verteices should be set in <paramref name="verticesColor"/>.</param>
		/// <param name="lastColoredVertex">The index of the last colored vertices.</param>
		/// <returns>true if whole the grah can be colored with the given number of colors; false otherwise.</returns>
		public bool CanColorizeVerticesWith(int maxColor, ref IList<int> verticesColor, out int lastColoredVertex, ref int curVertex)
		{
			return CanColorizeVerticesWith(maxColor, ref verticesColor, out lastColoredVertex, ref curVertex, null);
		}

		#endregion

		#region public bool CanColorizeVerticesWith(int maxColor, ref IList<int> verticesColor, out int lastColoredVertex, ref int curVertex, Func<IList<int>, bool> isPromising)

		/// <summary>
		/// Specifies if the graph can be colorized with a given number of colors.
		/// </summary>
		/// <param name="maxColor">Maximum number of different colors.</param>
		/// <param name="verticesColor">The colors of the verices.</param>
		/// <param name="lastColoredVertex">The index of the last colored vertices.</param>
		/// <param name="curVertex">The index of the vertex which coloring should start from. The color of the previous verteices should be set in <paramref name="verticesColor"/>.</param>
		/// <param name="isPromising">A function which can improve the algorithm with verifing if the current coloring is promising.</param>
		/// <returns>true if whole the grah can be colored with the given number of colors; false otherwise.</returns>
		public bool CanColorizeVerticesWith(int maxColor, ref IList<int> verticesColor, out int lastColoredVertex, ref int curVertex, Func<IList<int>, bool> isPromising)
		{
			if (m_nChromaticNumber != -1)
			{
				if (ChromaticNumber < maxColor)
				{
					verticesColor = new List<int>(m_lstVertexColors);
					lastColoredVertex = Order;
					return true;
				}
				else
				{
					verticesColor = null;
					lastColoredVertex = Order;
					return false;
				}
			}

			if ((verticesColor == null) || (verticesColor.Count != Order))
			{
				verticesColor = new List<int>(Order);

				for (int i = 0; i < m_nOrder; i++)
					verticesColor.Add(0);
			}

			lastColoredVertex = int.MinValue;
			do
			{
				if (verticesColor[curVertex] == maxColor)
				{
					IEnumerable<int> ebNeighbours = this.GetNeighborsOf(curVertex);
					int nMaxColoredNeighbour = -1;
					foreach (int nNeighbour in this.GetNeighborsOf(curVertex))
					{
						if ((nNeighbour < curVertex) && (nNeighbour > nMaxColoredNeighbour))
							nMaxColoredNeighbour = nNeighbour;
					}

					if (nMaxColoredNeighbour != -1)
					{
						while (curVertex > nMaxColoredNeighbour)
						{
							verticesColor[curVertex] = 0;
							curVertex--;
						}
						continue;
					}
					else
					{
						verticesColor[curVertex] = 0;
						curVertex--;
						continue;
					}
				}
				else
				{
					verticesColor[curVertex]++;
				}

				bool bIsPromising = true;
				foreach (int nNeighbour in this.GetNeighborsOf(curVertex))
				{
					if (verticesColor[nNeighbour] == verticesColor[curVertex])
					{
						bIsPromising = false;
						break;
					}
				}
				if (bIsPromising)
				{
					if ((isPromising == null) || isPromising(verticesColor))
					{
						if (curVertex > lastColoredVertex)
							lastColoredVertex = curVertex;
						curVertex++;
					}
				}
			} while ((curVertex > 0) && (curVertex < m_nOrder));

			return (curVertex == Order);
		}

		#endregion

		#region protected void ColorizeVertices()

		/// <summary>
		/// Colorize vertices.
		/// </summary>
		protected virtual void ColorizeVertices()
		{
			if (m_nChromaticNumber != -1)
				return;

			if (Order == 0)
			{
				m_nChromaticNumber = 0;
				m_lstVertexColors = new List<int>();
				m_nbIsBipartite = true;
			}
			else if (EdgeCount == 0)
			{
				m_nChromaticNumber = 1;
				List<int> lstColors = new List<int>(Order);
				for (int i = 0; i < m_nOrder; i++)
					lstColors.Add(1);
				m_lstVertexColors = lstColors;
				m_nbIsBipartite = true;
			}
			else if (!IsBipartite)
			{
				IList<int> lstCandidateColors = GetBrelazColoring();
				int nColor = lstCandidateColors.Max();
				int nChromaticNumber = nColor;
				m_lstVertexColors = lstCandidateColors;

				int nTemp;
				for (bool bMayBeBetter = (nColor > m_nMinNonBipartiteChromaticNumber); bMayBeBetter; )
				{
					nColor--;
					if (CanColorizeVerticesWith(nColor, out lstCandidateColors, out nTemp))
					{
						m_lstVertexColors = lstCandidateColors;
						nChromaticNumber = nColor;
					}
					else
						bMayBeBetter = false;
				}
				m_nChromaticNumber = nChromaticNumber;
			}
		}

		#endregion
	}
}
