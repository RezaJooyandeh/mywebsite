﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Diagnostics;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	/// <summary>
	/// Represents a simple graph. A simple graph is an undirected graph that has no loops and no more than one edge between any two different vertices
	/// </summary>
	[DebuggerDisplay("Order = {Order}, Edge Count = {EdgeCount}")]
	public partial class SimpleGraph: ICloneable, IEquatable<SimpleGraph>
	{
		#region .ctor

		/// <summary>
		/// Constructs an uninitialized <see cref="SimpleGraph"/>.
		/// </summary>
		protected internal SimpleGraph()
		{

		}

		#endregion

		#region ICloneable Members

		object ICloneable.Clone()
		{
			return Clone();
		}

		/// <summary>
		/// Makes a clone of the graph.
		/// </summary>
		/// <returns>The clone of the graph</returns>
		public SimpleGraph Clone()
		{
			SimpleGraph cGraph = new SimpleGraph();
			cGraph.Order = this.Order;
			cGraph.AdjancecyMatrix = new List<IList<int>>(this.Order);
			cGraph.EdgeCount = this.EdgeCount;
			cGraph.MaxDegree = this.MaxDegree;
			for (int i = 0; i < m_nOrder; i++)
			{
#if DEBUG
				cGraph.AdjancecyMatrix.Add(new DebugableList<int>(this.AdjancecyMatrix[i]));
#else
				cGraph.AdjancecyMatrix.Add(new List<int>(this.AdjancecyMatrix[i]));
#endif
			}
			return cGraph;
		}

		#endregion

		#region IEquatable<Graph> Members + object.Equals + object.GetHashCode

		/// <summary>
		/// Indicates whether the current graph is equal to another graph.
		/// </summary>
		/// <param name="other">A graph to compare with this graph.</param>
		/// <returns>true if the current graph is equal to the <paramref name="other"/> parameter; otherwise, false.</returns>
		public bool Equals(SimpleGraph other)
		{
			if (object.ReferenceEquals(other, null))
				return false;

			if (other.Order != this.Order)
				return false;

			if (other.EdgeCount != this.EdgeCount)
				return false;

			if (EdgeCount > Order)
			{
				for (int v = 0; v < m_nOrder; v++)
				{
					for (int w = 0; w < m_nOrder; w++)
					{
						if (AdjancecyMatrix[v][w] != other.AdjancecyMatrix[v][w])
							return false;
					}
				}
			}
			else
			{
				for (int e = 0; e < m_nEdgeCount; e++)
				{
					for (int v = 0; v < m_nOrder; v++)
					{
						if (IncidenceMatrix[v][e] != other.IncidenceMatrix[v][e])
							return false;
					}
				}
			}

			return true;
		}

		/// <summary>
		/// Determines whether the specified <see cref="System.Object"/> is equal to the current <see cref="SimpleGraph"/>.
		/// </summary>
		/// <param name="obj">The <see cref="System.Object"/> to compare with the current <see cref="SimpleGraph"/>.</param>
		/// <returns>true if the specified <see cref="System.Object"/> is equal to the current <see cref="SimpleGraph"/>; otherwise, false.</returns>
		public override bool Equals(object obj)
		{
			return Equals(obj as SimpleGraph);
		}

		/// <summary>
		/// Serves as a hash function for a <see cref="SimpleGraph"/>.
		/// </summary>
		/// <returns>A hash code for the current <see cref="SimpleGraph"/>.</returns>
		public override int GetHashCode()
		{
			if (!m_nbHashCode.HasValue)
				m_nbHashCode = Edges.Aggregate<Edge, int>(0, (workingHash, next) => next.GetHashCode() ^ workingHash);

			return m_nbHashCode.Value;
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int ?m_nbHashCode;

		#endregion

		#region public Graph Complement

		/// <summary>
		/// Gets a graph representing the complement of this graph.
		/// </summary>
		public SimpleGraph Complement
		{
			get
			{
				lock (m_oComplementSynchronizer)
				{
					if (m_cComplement == null)
					{
						m_cComplement = new SimpleGraph();
						m_cComplement.Order = Order;
						m_cComplement.AdjancecyMatrix = new List<IList<int>>(Order);
						for (int i = 0; i < m_nOrder; i++)
						{
#if DEBUG
							m_cComplement.AdjancecyMatrix.Add(new DebugableList<int>(Order));
#else
							m_cComplement.AdjancecyMatrix.Add(new List<int>(Order));
#endif
							for (int j = 0; j < i; j++)
								m_cComplement.AdjancecyMatrix[i].Add(1 - AdjancecyMatrix[i][j]);

							m_cComplement.AdjancecyMatrix[i].Add(0);

							for (int j = i + 1; j < m_nOrder; j++)
								m_cComplement.AdjancecyMatrix[i].Add(1 - AdjancecyMatrix[i][j]);
						}

						List<int> lstDegrees = new List<int>(Order);
						lstDegrees.AddRange(Degrees.Select(d => Order - d - 1));
						m_cComplement.Degrees = lstDegrees;
						m_cComplement.EdgeCount = Order * (Order - 1) / 2 - EdgeCount;
					}
				}

				return m_cComplement;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oComplementSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private SimpleGraph m_cComplement;

		#endregion

		#region public Graph LineGraph

		/// <summary>
		/// Gets the line graph of the current graph.
		/// </summary>
		public SimpleGraph LineGraph
		{
			get
			{
				lock (m_oLineGraphSynchronizer)
				{
					if (m_cLineGraph == null)
					{
						m_cLineGraph = new SimpleGraph() { Order = EdgeCount };
						m_cLineGraph.AdjancecyMatrix = new List<IList<int>>(m_nEdgeCount);
						for (int i = 0; i < m_nEdgeCount; i++)
						{
#if DEBUG
							m_cLineGraph.AdjancecyMatrix.Add(new DebugableList<int>(m_nEdgeCount));
#else
							m_cLineGraph.AdjancecyMatrix.Add(new List<int>(m_nEdgeCount));
#endif
							for (int j = 0; j < m_nEdgeCount; j++)
								m_cLineGraph.AdjancecyMatrix[i].Add(Edges[i].IsAdjacent(Edges[j]) ? 1 : 0);
						}

						List<int> lstDegrees = new List<int>(EdgeCount);
						for (int i = 0; i < m_nEdgeCount; i++)
							lstDegrees.Add(Degrees[Edges[i].V1] + Degrees[Edges[i].V2] - 2);

						m_cLineGraph.Degrees = lstDegrees;
						m_cLineGraph.EdgeCount = lstDegrees.Sum() / 2;
						m_cLineGraph.m_nMinNonBipartiteChromaticNumber = MaxDegree;
					}
				}

				return m_cLineGraph;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oLineGraphSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private SimpleGraph m_cLineGraph;

		#endregion

		#region public Graph TotalGraph

		/// <summary>
		/// Gets the Total graph of the current graph.
		/// </summary>
		public SimpleGraph TotalGraph
		{
			get
			{
				lock (m_oTotalGraphSynchronizer)
				{
					if (m_cTotalGraph == null)
					{
						int nTotalGraphOrder = EdgeCount + Order;
						m_cTotalGraph = new SimpleGraph() { Order = nTotalGraphOrder };
						m_cTotalGraph.AdjancecyMatrix = new List<IList<int>>(nTotalGraphOrder);
						for (int i = 0; i < Order; i++)
						{
#if DEBUG
							m_cTotalGraph.AdjancecyMatrix.Add(new DebugableList<int>(nTotalGraphOrder));
#else
							m_cTotalGraph.AdjancecyMatrix.Add(new List<int>(nTotalGraphOrder));
#endif

							for (int j = 0; j < Order; j++)
								m_cTotalGraph.AdjancecyMatrix[i].Add(AdjancecyMatrix[i][j]);
							for (int j = 0; j < m_nEdgeCount; j++)
								m_cTotalGraph.AdjancecyMatrix[i].Add(Edges[j].LiesOn(i) ? 1 : 0);
						}

						for (int i = 0; i < m_nEdgeCount; i++)
						{
#if DEBUG
							m_cTotalGraph.AdjancecyMatrix.Add(new DebugableList<int>(nTotalGraphOrder));
#else
							m_cTotalGraph.AdjancecyMatrix.Add(new List<int>(nTotalGraphOrder));
#endif
							for (int j = 0; j < Order; j++)
								m_cTotalGraph.AdjancecyMatrix[i + Order].Add(Edges[i].LiesOn(j) ? 1 : 0);

							for (int j = 0; j < m_nEdgeCount; j++)
								m_cTotalGraph.AdjancecyMatrix[i + Order].Add(Edges[i].IsAdjacent(Edges[j]) ? 1 : 0);
						}

						List<int> lstDegrees = new List<int>(nTotalGraphOrder);
						for (int i = 0; i < Order; i++)
							lstDegrees.Add(2 * Degrees[i]);

						for (int i = 0; i < m_nEdgeCount; i++)
							lstDegrees.Add(Degrees[Edges[i].V1] + Degrees[Edges[i].V2] /* -2 + 2*/);

						m_cTotalGraph.Degrees = lstDegrees;
						m_cTotalGraph.EdgeCount = lstDegrees.Sum() / 2;
					}
				}

				return m_cTotalGraph;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oTotalGraphSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private SimpleGraph m_cTotalGraph;

		#endregion

		#region public IList<IList<int>> AdjancecyMatrix

		/// <summary>
		/// Gets the adjancecy matrix of the graph.
		/// </summary>
		public IList<IList<int>> AdjancecyMatrix { get; internal set; }

		#endregion

		#region public IList<IList<int>> IncidenceMatrix

		/// <summary>
		/// Gets the incidence matrix of the graph.
		/// </summary>
		public IList<IList<int>> IncidenceMatrix
		{
			get
			{
				lock (m_oIncidenceMatrixSynchronizer)
				{
					if (m_lstIncidenceMatrix == null)
					{
						m_lstIncidenceMatrix = new List<IList<int>>(Order);

						for (int i = 0; i < m_nOrder; i++)
						{
#if DEBUG
							m_lstIncidenceMatrix.Add(new DebugableList<int>(m_nEdgeCount));
#else
							m_lstIncidenceMatrix.Add(new List<int>(m_nEdgeCount));
#endif
						}

						int eCounter = 0;
						foreach (Edge e in Edges)
						{
							for (int i = 0; i < m_nOrder; i++)
								m_lstIncidenceMatrix[i].Add(0);
							m_lstIncidenceMatrix[e.V1][eCounter] = 1;
							m_lstIncidenceMatrix[e.V2][eCounter] = 1;
							eCounter++;
						}
					}
				}

				return m_lstIncidenceMatrix;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIncidenceMatrixSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<IList<int>> m_lstIncidenceMatrix;

		#endregion

		#region public IList<IList<int>> LaplacianMatrix

		/// <summary>
		/// Gets the laplacian matrix of the graph.
		/// </summary>
		public IList<IList<int>> LaplacianMatrix
		{
			get
			{
				lock (m_oLaplacianMatrixSynchronizer)
				{
					if (m_lstLaplacianMatrix == null)
					{
						m_lstLaplacianMatrix = new List<IList<int>>(m_nOrder);

						for (int i = 0; i < m_nOrder; i++)
						{
#if DEBUG
							List<int> lstLaplacianRow = new DebugableList<int>(m_nOrder) { DebuggingDisplayLength = 3 };
#else
							List<int> lstLaplacianRow = new List<int>(m_nOrder);
#endif
							m_lstLaplacianMatrix.Add(lstLaplacianRow);
							IList<int> lstAdjancecyRow = AdjancecyMatrix[i];
							for (int j = 0; j < m_nOrder; j++)
								lstLaplacianRow.Add(-lstAdjancecyRow[j]);

							lstLaplacianRow[i] = Degrees[i];
						}
					}
				}

				return m_lstLaplacianMatrix;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oLaplacianMatrixSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<IList<int>> m_lstLaplacianMatrix;

		#endregion

		#region public IList<IList<int>> APlusDMatrix

		/// <summary>
		/// Gets the matrix which is made of the addition of adjancecy matrix and the diagonal matrix holding vertices degree.
		/// </summary>
		public IList<IList<int>> APlusDMatrix
		{
			get
			{
				lock (m_oAPlusDMatrixSynchronizer)
				{
					if (m_lstAPlusDMatrix == null)
					{
						m_lstAPlusDMatrix = new List<IList<int>>(m_nOrder);

						for (int i = 0; i < m_nOrder; i++)
						{
#if DEBUG
							List<int> lstAPlusXRow = new DebugableList<int>(m_nOrder);
#else
							List<int> lstAPlusXRow = new List<int>(m_nOrder);
#endif
							m_lstAPlusDMatrix.Add(lstAPlusXRow);
							IList<int> lstAdjancecyRow = AdjancecyMatrix[i];
							for (int j = 0; j < m_nOrder; j++)
								lstAPlusXRow.Add(lstAdjancecyRow[j]);

							lstAPlusXRow[i] = Degrees[i];
						}
					}
				}

				return m_lstAPlusDMatrix;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oAPlusDMatrixSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<IList<int>> m_lstAPlusDMatrix;

		#endregion

		#region public int MaxDegree

		/// <summary>
		/// Gets the maximum degree of vertices.
		/// </summary>
		public int MaxDegree
		{
			get
			{
				if (m_nMaxDegree == -1)
				{
					lock (m_oMaxDegreeSynchronizer)
					{
						if (m_nMaxDegree == -1)
							m_nMaxDegree = Degrees.Max();
					}
				}

				return m_nMaxDegree;
			}
			private set
			{
				lock (m_oMaxDegreeSynchronizer)
				{
					m_nMaxDegree = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oMaxDegreeSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nMaxDegree = -1;

		#endregion

		#region public int MinDegree

		/// <summary>
		/// Gets the minimum degree of vertices.
		/// </summary>
		public int MinDegree
		{
			get
			{
				if (m_nMinDegree == -1)
				{
					lock (m_oMinDegreeSynchronizer)
					{
						if (m_nMinDegree == -1)
							m_nMinDegree = Degrees.Min();
					}
				}

				return m_nMinDegree;
			}
			private set
			{
				lock (m_oMinDegreeSynchronizer)
				{
					m_nMinDegree = value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oMinDegreeSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nMinDegree = -1;

		#endregion

		#region public int Order

		/// <summary>
		/// Gets the order of the graph.
		/// </summary>
		public int Order
		{
			get { return m_nOrder; }
			internal set { m_nOrder = value; }
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nOrder;

		#endregion

		#region public int EdgeCount

		/// <summary>
		/// Gets the order of the graph.
		/// </summary>
		public int EdgeCount
		{
			get { return m_nEdgeCount; }
			internal set { m_nEdgeCount = value; }
		}
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int m_nEdgeCount;

		#endregion

		#region public IList<int> Degrees

		/// <summary>
		/// Gets the degrees of all vertices.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(Degrees)}")]
		public IList<int> Degrees { get; private set; }

		#endregion

		#region public IList<Edge> Edges

		/// <summary>
		/// Gets the list of edges of the graph.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(Edges)}")]
		public IList<Edge> Edges
		{
			get
			{
				lock (m_oEdgesSynchronizer)
				{
					if (m_lstEdges == null)
					{
						m_lstEdges = new List<Edge>(EdgeCount);
						for (int i = 0; i < m_nOrder; i++)
						{
							for (int j = i + 1; j < m_nOrder; j++)
							{
								if (AdjancecyMatrix[i][j] == 1)
									m_lstEdges.Add(new Edge(i, j));
							}
						}
					}
				}

				return m_lstEdges;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oEdgesSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<Edge> m_lstEdges;

		#endregion
	}
}
