﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gemini.Combinatorics
{
	/// <summary>
	/// Represents some collections of graphs.
	/// </summary>
	public class SimpleGraphs
	{
		#region public static IEnumerable<SimpleGraph> GetCompletes

		/// <summary>
		/// Returns all complete graphs of order 1 to <see cref="Int32.MaxValue"/>.
		/// </summary>
		/// <returns>All complete graphs of order 1 to <see cref="Int32.MaxValue"/>.</returns>
		public static IEnumerable<SimpleGraph> GetCompletes()
		{
			return GetCompletes(1, int.MaxValue);
		}

		/// <summary>
		/// Returns all complete graphs of order 1 to a given order.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <returns>All complete graphs of order 1 to <paramref name="maxOrder" />.</returns>
		public static IEnumerable<SimpleGraph> GetCompletes(int maxOrder)
		{
			return GetCompletes(1, maxOrder);
		}

		/// <summary>
		/// Returns all complete graphs in a range of given orders.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <param name="minOrder">The maximum order of the output graphs.</param>
		/// <returns>All complete graphs of order <paramref name="minOrder"/> to <paramref name="maxOrder"/>.</returns>
		public static IEnumerable<SimpleGraph> GetCompletes(int minOrder, int maxOrder)
		{
			for (int i = minOrder; i <= maxOrder; i++)
				yield return SimpleGraph.CompleteOfOrder(i);
		}

		#endregion

		#region public static IEnumerable<SimpleGraph> GetCycles

		/// <summary>
		/// Returns all cycle graphs of order 1 to <see cref="Int32.MaxValue"/>.
		/// </summary>
		/// <returns>All cycle graphs of order 1 to <see cref="Int32.MaxValue"/>.</returns>
		public static IEnumerable<SimpleGraph> GetCycles()
		{
			return GetCycles(1, int.MaxValue);
		}

		/// <summary>
		/// Returns all cycle graphs of order 1 to a given order.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <returns>All cycle graphs of order 1 to <paramref name="maxOrder" />.</returns>
		public static IEnumerable<SimpleGraph> GetCycles(int maxOrder)
		{
			return GetCycles(1, maxOrder);
		}

		/// <summary>
		/// Returns all cycle graphs in a range of given orders.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <param name="minOrder">The maximum order of the output graphs.</param>
		/// <returns>All cycle graphs of order <paramref name="minOrder"/> to <paramref name="maxOrder"/>.</returns>
		public static IEnumerable<SimpleGraph> GetCycles(int minOrder, int maxOrder)
		{
			for (int i = minOrder; i <= maxOrder; i++)
				yield return SimpleGraph.CycleOfOrder(i);
		}

		#endregion

		#region public static IEnumerable<SimpleGraph> GetStars

		/// <summary>
		/// Returns all star graphs of order 1 to <see cref="Int32.MaxValue"/>.
		/// </summary>
		/// <returns>All star graphs of order 1 to <see cref="Int32.MaxValue"/>.</returns>
		public static IEnumerable<SimpleGraph> GetStars()
		{
			return GetStars(1, int.MaxValue);
		}

		/// <summary>
		/// Returns all star graphs of order 1 to a given order.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <returns>All star graphs of order 1 to <paramref name="maxOrder" />.</returns>
		public static IEnumerable<SimpleGraph> GetStars(int maxOrder)
		{
			return GetStars(1, maxOrder);
		}

		/// <summary>
		/// Returns all star graphs in a range of given orders.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <param name="minOrder">The maximum order of the output graphs.</param>
		/// <returns>All star graphs of order <paramref name="minOrder"/> to <paramref name="maxOrder"/>.</returns>
		public static IEnumerable<SimpleGraph> GetStars(int minOrder, int maxOrder)
		{
			for (int i = minOrder; i <= maxOrder; i++)
				yield return SimpleGraph.StarOfOrder(i);
		}

		#endregion

		#region public static IEnumerable<SimpleGraph> GetWheels

		/// <summary>
		/// Returns all wheel graphs of order 1 to <see cref="Int32.MaxValue"/>.
		/// </summary>
		/// <returns>All wheel graphs of order 1 to <see cref="Int32.MaxValue"/>.</returns>
		public static IEnumerable<SimpleGraph> GetWheels()
		{
			return GetWheels(1, int.MaxValue);
		}

		/// <summary>
		/// Returns all wheel graphs of order 1 to a given order.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <returns>All wheel graphs of order 1 to <paramref name="maxOrder" />.</returns>
		public static IEnumerable<SimpleGraph> GetWheels(int maxOrder)
		{
			return GetWheels(1, maxOrder);
		}

		/// <summary>
		/// Returns all wheel graphs in a range of given orders.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <param name="minOrder">The maximum order of the output graphs.</param>
		/// <returns>All wheel graphs of order <paramref name="minOrder"/> to <paramref name="maxOrder"/>.</returns>
		public static IEnumerable<SimpleGraph> GetWheels(int minOrder, int maxOrder)
		{
			for (int i = minOrder; i <= maxOrder; i++)
				yield return SimpleGraph.WheelOfOrder(i);
		}

		#endregion

		#region public static IEnumerable<SimpleGraph> GetPaths

		/// <summary>
		/// Returns all paths of order 1 to <see cref="Int32.MaxValue"/>.
		/// </summary>
		/// <returns>All paths of order 1 to <see cref="Int32.MaxValue"/>.</returns>
		public static IEnumerable<SimpleGraph> GetPaths()
		{
			return GetPaths(1, int.MaxValue);
		}

		/// <summary>
		/// Returns all paths of order 1 to a given order.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <returns>All paths of order 1 to <paramref name="maxOrder" />.</returns>
		public static IEnumerable<SimpleGraph> GetPaths(int maxOrder)
		{
			return GetPaths(1, maxOrder);
		}

		/// <summary>
		/// Returns all paths in a range of given orders.
		/// </summary>
		/// <param name="maxOrder">The maximum order of the output graphs.</param>
		/// <param name="minOrder">The maximum order of the output graphs.</param>
		/// <returns>All paths of order <paramref name="minOrder"/> to <paramref name="maxOrder"/>.</returns>
		public static IEnumerable<SimpleGraph> GetPaths(int minOrder, int maxOrder)
		{
			for (int i = minOrder; i <= maxOrder; i++)
				yield return SimpleGraph.PathOfOrder(i);
		}

		#endregion
	}
}
