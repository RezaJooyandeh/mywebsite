﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Collections.ObjectModel;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region AdjancecyEigenvalues

		/// <summary>
		/// Gets the eigenvalues of the adjancecy matrix of the graph.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(AdjancecyEigenvalues, 3)}")]
		public IList<double> AdjancecyEigenvalues
		{
			get
			{
				lock (m_oAdjancecyEigenValuesSynchronizer)
				{
					if (m_lstAdjancecyEigenvalues == null)
						m_lstAdjancecyEigenvalues = new ReadOnlyCollection<double>(AdjancecyMatrix.GetEigenvalues());
				}

				return m_lstAdjancecyEigenvalues;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ReadOnlyCollection<double> m_lstAdjancecyEigenvalues;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oAdjancecyEigenValuesSynchronizer = new object();

		#endregion

		#region IncidenceSingularValues

		/// <summary>
		/// Gets the singular values of the adjancecy matrix of the graph.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(IncidenceSingularValues, 3)}")]
		public IList<double> IncidenceSingularValues
		{
			get
			{
				lock (m_oIncidenceSingularValuesSynchronizer)
				{
					if (m_lstIncidenceSingularValues == null)
						m_lstIncidenceSingularValues = new ReadOnlyCollection<double>(IncidenceMatrix.GetSingularvalues(Order, EdgeCount));
				}
		
				return m_lstIncidenceSingularValues;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ReadOnlyCollection<double> m_lstIncidenceSingularValues;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIncidenceSingularValuesSynchronizer = new object();

		#endregion

		#region LaplacianEigenvalues

		/// <summary>
		/// Gets the eigenvalues of the laplacian matrix of the graph.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(LaplacianEigenvalues, 3)}")]
		public IList<double> LaplacianEigenvalues
		{
			get
			{
				lock (m_oLaplacianEigenValuesSynchronizer)
				{
					if (m_lstLaplacianEigenvalues == null)
						m_lstLaplacianEigenvalues = new ReadOnlyCollection<double>(LaplacianMatrix.GetEigenvaluesDescending());
				}

				return m_lstLaplacianEigenvalues;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ReadOnlyCollection<double> m_lstLaplacianEigenvalues;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oLaplacianEigenValuesSynchronizer = new object();

		#endregion

		#region APlusDEigenvalues

		/// <summary>
		/// Gets the eigenvalues of the matrix wichi is produced by adding degrees on the diagonal of the adjancecy matrix of the graph.
		/// </summary>
		[DebuggerDisplay("{Gemini.Collections.Specialized.DebuggerHelper.ListToString(APlusDEigenvalues, 3)}")]
		public IList<double> APlusDEigenvalues
		{
			get
			{
				lock (m_oAPlusDEigenValuesSynchronizer)
				{
					if (m_lstAPlusDEigenvalues == null)
						m_lstAPlusDEigenvalues = new ReadOnlyCollection<double>(APlusDMatrix.GetEigenvalues());
				}

				return m_lstAPlusDEigenvalues;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private ReadOnlyCollection<double> m_lstAPlusDEigenvalues;
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oAPlusDEigenValuesSynchronizer = new object();

		#endregion
	}
}
