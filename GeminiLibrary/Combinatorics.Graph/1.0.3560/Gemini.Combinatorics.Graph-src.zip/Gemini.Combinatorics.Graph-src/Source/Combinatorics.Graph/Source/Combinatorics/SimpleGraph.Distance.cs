﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Gemini.Collections.Specialized;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public IList<IList<int>> Distances

		/// <summary>
		/// Gets the distance matrix of the graph.
		/// </summary>
		public IList<IList<int>> Distances
		{
			get
			{
				lock (m_oDistancesSynchronizer)
				{
					if (m_lstDistances == null)
					{
						int nOrder = Order;
						m_lstDistances = new List<IList<int>>(nOrder);

						for (int i = 0; i < nOrder; i++)
						{
#if DEBUG
							List<int> lstRow = new DebugableList<int>(AdjancecyMatrix[i].Select(n => (n == 0) ? InfinityDistance : n));
#else
							List<int> lstRow = new List<int>(AdjancecyMatrix[i].Select(n => (n == 0) ? InfinityDistance : n));
#endif
							lstRow[i] = 0;
							m_lstDistances.Add(lstRow);
						}

						for (int k = 0; k < nOrder; k++)
						{
							for (int i = 0; i < nOrder; i++)
							{
								if (i == k)
									continue;
								for (int j = 0; j < nOrder; j++)
								{
									if ((j == i) || (j == k))
										continue;

									int d_ij = m_lstDistances[i][j];
									int d_ik = m_lstDistances[i][k];
									int d_kj = m_lstDistances[k][j];

									if ((d_ik != InfinityDistance) && (d_kj != InfinityDistance))
									{
										if ((d_ij == InfinityDistance) || (d_ij > d_ik + d_kj))
											m_lstDistances[i][j] = d_ik + d_kj;
									}
								}
							}
						}
					}
				}

				return m_lstDistances;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oDistancesSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private List<IList<int>> m_lstDistances;

		#endregion

		#region public int Diameter

		/// <summary>
		/// Gets the diameter of the graph.
		/// </summary>
		public int Diameter
		{
			get
			{
				lock (m_oDiameterSynchronizer)
				{
					if (!m_nbDiameter.HasValue)
					{
						if (Order <= 1)
							m_nbDiameter = 0;
						else
						{
							m_nbDiameter = 0;
							for (int i = 0; i < Order; i++)
							{
								for (int j = i + 1; j < Order; j++)
								{
									if (Distances[i][j] == InfinityDistance)
									{
										m_nbDiameter = InfinityDistance;
										goto DiameterComputed;
									}
									else if (Distances[i][j] > m_nbDiameter)
										m_nbDiameter = Distances[i][j];
								}
							}
						}
					}
				}
			DiameterComputed:

				return m_nbDiameter.Value;
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oDiameterSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private int? m_nbDiameter;

		#endregion

		/// <summary>
		/// The value indicating the infinite distance.
		/// </summary>
		public const int InfinityDistance = -1;
	}
}
