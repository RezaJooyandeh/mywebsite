﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace Gemini.Combinatorics
{
	static class MatrixExtensions
	{
		public static TDest[,] ConvertToArray<TSource, TDest>(IList<IList<TSource>> source, int rowCount, int columnCount)
		{
			TypeCode eDestTypeCode = Convert.GetTypeCode(default(TDest));
			TDest[,] arrRetVal = new TDest[rowCount, columnCount];
			for (int i = 0; i < rowCount; i++)
			{
				for (int j = 0; j < columnCount; j++)
					arrRetVal[i, j] = (TDest)Convert.ChangeType(source[i][j], eDestTypeCode);
			}
			return arrRetVal;
		}

		public static List<double> GetEigenvaluesAscending(this IList<IList<int>> self)
		{
			List<double> lstEigenvalues = self.GetEigenvalues();
			lstEigenvalues.Sort();
			return lstEigenvalues;
		}

		public static List<double> GetEigenvaluesDescending(this IList<IList<int>> self)
		{
			List<double> lstEigenvalues = self.GetEigenvalues();
			lstEigenvalues.Sort((i, j) => (i > j) ? -1 : (i == j) ? 0 : 1);
			return lstEigenvalues;
		}

		public static List<double> GetEigenvalues(this IList<IList<int>> self)
		{
			int size = self.Count;
			ExternalComponents.AlgLib.Complex [,]matrix = new ExternalComponents.AlgLib.Complex[size, size];
			for (int i = 0; i < size; i++)
			{
				for (int j = 0; j < size; j++)
					matrix[i, j] = self[i][j];
			}

			double []eigenvalues = null;
			ExternalComponents.AlgLib.Complex [,]eigenVectors = null;
			ExternalComponents.AlgLib.hevd.hmatrixevd(matrix, size, 0, false, ref eigenvalues, ref eigenVectors);
			List<double> lstEigenValues = new List<double>(size);
			foreach (double d in eigenvalues)
				lstEigenValues.Add(d);

			return lstEigenValues;
		}

		public static List<double> GetSingularvalues(this IList<IList<int>> self, int rowCount, int columnCount)
		{
			if ((rowCount == 0) || (columnCount == 0))
				return new List<double>();

			int size = self.Count;
			double [,]matrix = new double[rowCount, columnCount];
			for (int i = 0; i < rowCount; i++)
			{
				for (int j = 0; j < columnCount; j++)
					matrix[i, j] = self[i][j];
			}

			double []singularValues = null;
			double [,]u = null;
			double [,]v = null;
			ExternalComponents.AlgLib.svd.rmatrixsvd(matrix, rowCount, columnCount, 0, 0, 2, ref singularValues, ref u, ref v);
			List<double> lstSingularValues = new List<double>(size);
			foreach (double d in singularValues)
				lstSingularValues.Add(d);
			return lstSingularValues;
		}
	}
}
