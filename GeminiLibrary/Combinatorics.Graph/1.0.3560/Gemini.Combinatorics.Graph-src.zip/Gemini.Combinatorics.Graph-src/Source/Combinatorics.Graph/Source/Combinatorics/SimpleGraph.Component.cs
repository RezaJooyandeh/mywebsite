﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gemini.Collections;
using System.Diagnostics;

namespace Gemini.Combinatorics
{
	partial class SimpleGraph
	{
		#region public IList<int> GetComponentIndexes(int vertex)

		/// <summary>
		/// Returns the index of vertices of the maximal component which contains a given vertex.
		/// </summary>
		/// <param name="vertexIndex">The index of the vertex whose component is computing.</param>
		/// <returns>The index of vertices of the maximal component which contains a given vertex.</returns>
		public IList<int> GetComponentIndexes(int vertexIndex)
		{
			List<int> arrRetVal = new List<int>(Order);
			Queue<int> vertices = new Queue<int>(Order);
			vertices.Enqueue(vertexIndex);
			arrRetVal.Add(vertexIndex);
			int[] arrVisiteds = new int[Order];
			arrVisiteds[0] = 1;

			while (vertices.Count != 0)
			{
				int cur = vertices.Dequeue();
				for (int i = 0; i < m_nOrder; i++)
				{
					if (AdjancecyMatrix[cur][i] == 1)
					{
						if (arrVisiteds[i] == 0)
						{
							vertices.Enqueue(i);
							arrRetVal.Add(i);
							arrVisiteds[i] = 1;
						}
					}
				}
			}
			return arrRetVal;
		}

		#endregion

		#region public Graph GetComponent(int vertex)

		/// <summary>
		/// Return the maximal component which contains a given vertex.
		/// </summary>
		/// <param name="vertexIndex">The index of the vertex whose component is computing.</param>
		/// <returns>The maximal component which contains a given vertex.</returns>
		public SimpleGraph GetComponent(int vertexIndex)
		{
			IList<int> lstIndexes = GetComponentIndexes(vertexIndex);

			IList<IList<int>> lstAdjancecy = new List<IList<int>>(lstIndexes.Count);
			foreach (int index in lstIndexes)
				lstAdjancecy.Add(new SubList<int>(AdjancecyMatrix[index], lstIndexes));

			return SimpleGraph.FromAdjancecyMatrix(lstAdjancecy, lstAdjancecy.Count);
		}

		#endregion

		#region public bool IsConnected

		/// <summary>
		/// Gets the value indicating if the graph is connected.
		/// </summary>
		public bool IsConnected
		{
			get
			{
				lock (m_oIsConnectedSynchronizer)
				{
					if (!m_nbIsConnected.HasValue)
					{
						if (Order == 0)
							m_nbIsConnected = true;
						else
							m_nbIsConnected = (GetComponentIndexes(0).Count == Order);
					}

					return m_nbIsConnected.Value;
				}
			}
		}

		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private object m_oIsConnectedSynchronizer = new object();
		[DebuggerBrowsable(DebuggerBrowsableState.Never)]
		private bool? m_nbIsConnected;

		#endregion
	}
}
