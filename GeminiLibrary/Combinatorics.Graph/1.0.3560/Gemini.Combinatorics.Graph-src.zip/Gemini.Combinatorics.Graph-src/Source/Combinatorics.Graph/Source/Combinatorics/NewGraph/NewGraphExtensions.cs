﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace Gemini.Combinatorics.NewGraph
{
	public static class NewGraphExtensions
	{
		/// <summary>
		/// Saves a <see cref="SimpleGraph"/> as a xml file in the format of New Graph software.
		/// </summary>
		/// <param name="self">The graph to be saved.</param>
		/// <param name="fileName">The target path.</param>
		public static void SaveAsNewGraph(this SimpleGraph self, string fileName)
		{
			using (StreamWriter sw = new StreamWriter(fileName))
			{
				sw.WriteLine(
					"<graphml>" +
						"<key id=\"x\" for=\"node\"/>" + Environment.NewLine +
						"<key id=\"y\" for=\"node\"/>" + Environment.NewLine +
						"<key id=\"weight\" for=\"node\"/>" + Environment.NewLine +
						"<graph edgedefault=\"undirected\">");

				int nVertexCount = self.Order;
				for (int i = 1; i <= nVertexCount; i++)
				{
					double dArc = 2 * Math.PI * (i - 1) / nVertexCount;
					sw.WriteLine("<node id=\"v{0}\">", i);
						sw.WriteLine("<data key=\"x\">{0}</data>", 100 + (int)(nVertexCount * 100 * Math.Cos(dArc)));
						sw.WriteLine("<data key=\"y\">{0}</data>", 100 + (int)(nVertexCount * 100 * Math.Sin(dArc)));
					sw.WriteLine("</node>");
					sw.WriteLine();
				}

				foreach (Edge e in self.Edges)
					sw.WriteLine("<edge source=\"v{0}\" target=\"v{1}\"></edge>", e.V1 + 1, e.V2 + 1);

				sw.WriteLine(
						"</graph>" + Environment.NewLine +
					"</graphml>");
			}
		}
	}
}
