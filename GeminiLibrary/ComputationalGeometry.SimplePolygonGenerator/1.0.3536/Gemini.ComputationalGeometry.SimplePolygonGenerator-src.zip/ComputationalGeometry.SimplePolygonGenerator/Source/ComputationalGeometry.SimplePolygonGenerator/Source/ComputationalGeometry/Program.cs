﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Gemini.ComputationalGeometry.DataSet;
using System.Drawing;
using Gemini.ComputationalGeometry.PolygonGeneration;
using System.IO;
using System.ComponentModel;
using System.Diagnostics;

namespace Gemini.ComputationalGeometry
{
	class Program
	{
		static void Main(string[] args)
		{
			Polygon2DGeneratorType generatorType = Polygon2DGeneratorType.Unknown;
			int polygonCount = -1;
			int polygonSize = -1;
			int randomSeed = 0;
			RectangleF selectionRegion = new RectangleF(0, 0, 1, 1);
			string outFilePath = null;

			RandomPolygon2DSetBase polygonSet;

			try
			{
				ReadParams(args, ref outFilePath, ref generatorType, ref polygonCount, ref polygonSize, ref randomSeed, ref selectionRegion);

				if (polygonCount == -1)
					throw new ArgumentNullException(string.Empty, "polygonCount");

				if (polygonSize == -1)
					throw new ArgumentNullException(string.Empty, "polygonSize");

				switch (generatorType)
				{
					case Polygon2DGeneratorType.Unknown:
						throw new ArgumentNullException(string.Empty, "generatorType");
					case Polygon2DGeneratorType.SpacePart:
						polygonSet = new SpacePartPolygon2DSet(polygonSize, polygonCount, selectionRegion, randomSeed);
						break;
					case Polygon2DGeneratorType.Monotone:
						polygonSet = new MonotonePolygon2DSet(polygonSize, polygonCount, selectionRegion, randomSeed);
						break;
					default:
						Debug.Assert(false, "Program flow must not reach here.");
						throw new WarningException("Program flow must not reach here.");
				}
			}
			catch (ArgumentException)
			{
				PrintUsage();
				return;
			}

			TextWriter tw = null;
			try
			{
				tw = (outFilePath == null) ? Console.Out : new StreamWriter(outFilePath);

				try
				{
					int index = 1;
					foreach (SimplePolygon2D polygon in polygonSet)
					{
						tw.WriteLine("Simple Polygon {0} of {1}:", index, polygonCount);
						tw.WriteLine();
		
						foreach (PointF vertex in polygon.Vertices)
							tw.WriteLine("{0} {1}", vertex.X.ToString("00000000.00000000"), vertex.Y.ToString("00000000.00000000"));

						tw.WriteLine();
						index++;
					}
				}
				catch (Exception e)
				{
					Debug.Assert(false, e.ToString());
					Console.WriteLine("Exception occured: " + e.ToString());
				}
			}
			finally
			{
				if ((outFilePath != null) && (tw != null))
					tw.Dispose();
			}
		}

		private static void ReadParams(string[] args, ref string outFilePath, ref Polygon2DGeneratorType generatorType, ref int polygonCount, ref int polygonSize, ref int randomSeed, ref RectangleF selectionRegion)
		{
			foreach (string param in args)
			{
				if (param[0] != '/')
				{
					PrintUsage();
					return;
				}

				int colonIndex = param.IndexOf(':');
				string paramName = (colonIndex == -1) ? param.Substring(1) : param.Substring(1, colonIndex - 1);
				string paramValue = (colonIndex == -1) ? string.Empty : param.Substring(colonIndex + 1);
				string paramNameToLower = paramName.ToLower();
				string paramValueToLower = paramValue.ToLower();

				switch (paramNameToLower)
				{
					case "of":
					case "outfile":
					{
						outFilePath = paramValue;
						break;
					}
					case "gt":
					case "generatortype":
					{
						switch (paramValueToLower)
						{
							case "monotone":
								generatorType = Polygon2DGeneratorType.Monotone;
								break;
							case "spacepart":
								generatorType = Polygon2DGeneratorType.SpacePart;
								break;
						}
						break;
					}
					case "pc":
					case "polygoncount":
					{
						try
						{
							polygonCount = int.Parse(paramValue);
							break;
						}
						catch (Exception e)
						{
							throw new ArgumentException(string.Empty, paramNameToLower, e);
						}
					}
					case "ps":
					case "polygonsize":
					{
						try
						{
							polygonSize = int.Parse(paramValue);
							break;
						}
						catch (Exception e)
						{
							throw new ArgumentException(string.Empty, paramNameToLower, e);
						}
					}
					case "rs":
					case "randomseed":
					{
						try
						{
							randomSeed = int.Parse(paramValue);
							break;
						}
						catch (Exception e)
						{
							throw new ArgumentException(string.Empty, paramNameToLower, e);
						}
					}
					case "sr":
					case "selectionregion":
					{
						if ((paramValue[0] != '[') || (paramValue[paramValue.Length - 1] != ']'))
							throw new ArgumentException(string.Empty, paramNameToLower);
						string[] parts = paramValue.Substring(1, paramValue.Length - 2).Split(',');
						if (parts.Length != 4)
							throw new ArgumentException(string.Empty, paramNameToLower);
						float[] floatParts = new float[4];
						try
						{
							for (int i = 0; i < 4; i++)
								floatParts[i] = float.Parse(parts[i]);
						}
						catch (Exception e)
						{
							throw new ArgumentException(string.Empty, paramNameToLower, e);
						}
						selectionRegion = new RectangleF(floatParts[0], floatParts[1], floatParts[2], floatParts[3]);
						break;
					}
					default:
						throw new ArgumentException(string.Empty, paramNameToLower);
				}
			}
		}

		private static void PrintUsage()
		{
			Console.WriteLine("USAGE:");
			Console.WriteLine("  Gemini.ComputationalGeometry.SimplePolygonGenerator.exe");
			Console.WriteLine("    /gt:PolygonGeneratorType][/GeneratorType:PolygonGeneratorType");
			Console.WriteLine("    /ps:PolygonVertexCount][/PolygonSize:PolygonVertexCount");
			Console.WriteLine("    [/of:OutFilePath][/OutFile:OutFilePath]");
			Console.WriteLine("    [/sr:VerticesRegion][/SelectionRegion:VerticesRegion]");
			Console.WriteLine("    [/rs:GeneratorRandomSeed][/RandomSeed:GeneratorRandomSeed]");
			Console.WriteLine();
			Console.WriteLine("  PolygonGeneratorType: One of the values of \"SpacePart\" or \"Monotone\".");
			Console.WriteLine("  PolygonVertexCount: Number of the vertices of each generating polygon.");
			Console.WriteLine("  OutFilePath: Path of the output file.");
			Console.WriteLine("  VerticesRegion: The range in of vertices in the form of [x,y,width,height].");
			Console.WriteLine("  GeneratorRandomSeed: The seed of random generator.");
			Console.WriteLine();
			Console.WriteLine("Sample Usages:");
			Console.WriteLine("  /gt:SpacePart /ps:30 /pc:100");
			Console.WriteLine("  /gt:Monotone /ps:30 /pc:100 /of:Poly30x100.txt");
			Console.WriteLine("  /gt:Monotone /ps:30 /pc:100 /rs:2");
			Console.WriteLine("  /gt:SpacePart /ps:30 /pc:100 /sr:[20,20,10,10]");
		}
	}
}
