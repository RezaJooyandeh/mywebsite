﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
using System.Drawing;
using System.Collections;

namespace Gemini.ComputationalGeometry.DataSet
{
	/// <summary>
	/// Represents the base class for a set of 2-dimentional simple polygons.
	/// </summary>
	[Serializable]
	public abstract class RandomPolygon2DSetBase
		: ICollection<SimplePolygon2D>
		, ISerializable
	{
		#region .ctor

		/// <summary>
		/// Initializes a new instance of <see cref="RandomPolygon2DSetBase"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		protected RandomPolygon2DSetBase(int vertexCount)
			: this(vertexCount, vertexCount * 1000)
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="RandomPolygon2DSetBase"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		protected RandomPolygon2DSetBase(int vertexCount, int setSize)
			: this(vertexCount, setSize, new RectangleF(0, 0, 1, 1))
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="RandomPolygon2DSetBase"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		/// <param name="region">The region from which the vertices are selected.</param>
		protected RandomPolygon2DSetBase(int vertexCount, int setSize, RectangleF region)
			: this(vertexCount, setSize, region, 0)
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="RandomPolygon2DSetBase"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		/// <param name="region">The region from which the vertices are selected.</param>
		/// <param name="seed">The initializing random seed for generating polygons.</param>
		protected RandomPolygon2DSetBase(int vertexCount, int setSize, RectangleF region, int seed)
		{
			this.VertexCount = vertexCount;
			this.Count = setSize;
			this.Region = region;
			this.RandomSeed = seed;

			Initialize();
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="RandomPolygon2DSetBase"/> class with serialized data.
		/// </summary>
		/// <param name="info">The <see cref="SerializationInfo"/> that holds the serialized object data about the random polygon set.</param>
		/// <param name="context">The <see cref="StreamingContext"/> that contains contextual information about the source or destination.</param>
		protected RandomPolygon2DSetBase(SerializationInfo info, StreamingContext context)
		{
			Count = info.GetInt32("Count");
			Region = (RectangleF)info.GetValue("Region", typeof(RectangleF));
			RandomSeed = info.GetInt32("Seed");
		}

		#endregion

		#region ISerializable Members

		/// <summary>
		/// Sets the <see cref="SerializationInfo"/> with information about the random polygon set.
		/// </summary>
		/// <param name="info">The <see cref="SerializationInfo"/> that holds the serialized object data about the simple polygon.</param>
		/// <param name="context">The <see cref="StreamingContext"/> that contains contextual information about the source or destination.</param>
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("Count", Count);
			info.AddValue("Region", Region);
			info.AddValue("Seed", RandomSeed);
		}

		#endregion

		#region ICollection<SimplePolygon2D> Members

		/// <summary>
		/// Adds an item to the <see cref="ICollection{T}"/>. This implementation always throws <see cref="NotSupportedException"/>.
		/// </summary>
		/// <param name="item">The polygon to add to the <see cref="ICollection{T}"/>.</param>
		void ICollection<SimplePolygon2D>.Add(SimplePolygon2D item)
		{
			throw new NotSupportedException();
		}

		/// <summary>
		/// Removes all items from the <see cref="ICollection{T}"/>. This implementation always throws <see cref="NotSupportedException"/>.
		/// </summary>
		void ICollection<SimplePolygon2D>.Clear()
		{
			throw new NotSupportedException();
		}

		/// <summary>
		/// Determines whether the <see cref="RandomPolygon2DSetBase"/> contains a specific value.
		/// </summary>
		/// <param name="item">The item to be searched for.</param>
		/// <returns>true if the <see cref="SimplePolygon2D"/> is found in the <see cref="RandomPolygon2DSetBase"/>; otherwise, false.</returns>
		bool ICollection<SimplePolygon2D>.Contains(SimplePolygon2D item)
		{
			if (object.ReferenceEquals(item, null))
				return false;

			foreach (SimplePolygon2D p in this)
			{
				if (item.Equals(p))
					return true;
			}

			return false;
		}

		/// <summary>
		/// Determines whether an element is in the <see cref="RandomPolygon2DSetBase"/>.
		/// </summary>
		/// <param name="array">The one-dimensional <see cref="Array"/> that is the destination
		/// of the elements copied from <see cref="RandomPolygon2DSetBase"/>. The <see cref="Array"/> must have zero-based indexing.</param>
		/// <param name="index"></param>
		public void CopyTo(SimplePolygon2D[] array, int index)
		{
			foreach (SimplePolygon2D p in this)
				array[index++] = p;
		}

		/// <summary>
		/// Gets the number of elements contained in the <see cref="RandomPolygon2DSetBase"/> instance.
		/// </summary>
		public int Count { get; private set; }

		/// <summary>
		/// Gets a value indicating whether the set is read-only.
		/// </summary>
		bool ICollection<SimplePolygon2D>.IsReadOnly
		{
			get { return true; }
		}

		/// <summary>
		/// Removes the first occurrence of a specific object from the <see cref="RandomPolygon2DSetBase"/>. This implementation always throws <see cref="NotSupportedException"/>.
		/// </summary>
		/// <param name="item"></param>
		/// <returns></returns>
		bool ICollection<SimplePolygon2D>.Remove(SimplePolygon2D item)
		{
			throw new NotSupportedException();
		}

		#endregion

		#region IEnumerable<Polygon2D> Members

		/// <summary>
		/// Returns an enumerator that iterates through the set.
		/// </summary>
		/// <returns>A <see cref="IEnumerator{SimplePolygon2D}"/> that can be used to iterate through the set.</returns>
		public IEnumerator<SimplePolygon2D> GetEnumerator()
		{
			Random randomGenerator = new Random(RandomSeed);
			for (int i = 0; i < Count; i++)
			{
				SimplePolygon2D poly;

				while (true)
				{
					try
					{
						poly = Generate(VertexCount, Region, randomGenerator);
						break;
					}
					catch (Exception)
					{
					}
				}

				yield return poly;
			}
		}

		#endregion

		#region IEnumerable Members

		/// <summary>
		/// Returns an enumerator that iterates through the set.
		/// </summary>
		/// <returns>A <see cref="IEnumerator"/> that can be used to iterate through the set.</returns>
		IEnumerator IEnumerable.GetEnumerator()
		{
			return GetEnumerator();
		}

		#endregion

		/// <summary>
		/// When implemented in a derived class, generates a <see cref="SimplePolygon2D"/>.
		/// </summary>
		/// <param name="vertexCount">The number of the vertices of the generating polygon.</param>
		/// <param name="region">The region in which the vertices are selecting.</param>
		/// <param name="randomGenerator">The random generator which is used for generating set members.</param>
		/// <returns>The generated polygon.</returns>
		protected abstract SimplePolygon2D Generate(int vertexCount, RectangleF region, Random randomGenerator);

		/// <summary>
		/// Initializes the set before starting enumeration over it.
		/// </summary>
		protected virtual void Initialize()
		{
		}

		/// <summary>
		/// Gets the vertex count of each set member.
		/// </summary>
		protected int VertexCount { get; private set; }

		/// <summary>
		/// Gets the region in which the polygon vertecies are chosen.
		/// </summary>
		protected RectangleF Region { get; private set; }

		/// <summary>
		/// Gets the initializing random seed for generating polygons.
		/// </summary>
		private int RandomSeed { get; set; }
	}
}
