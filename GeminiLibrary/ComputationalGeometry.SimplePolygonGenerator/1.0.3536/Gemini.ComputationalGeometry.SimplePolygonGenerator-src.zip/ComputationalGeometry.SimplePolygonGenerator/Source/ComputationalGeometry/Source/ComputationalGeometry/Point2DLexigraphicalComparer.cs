﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace Gemini.ComputationalGeometry
{
	/// <summary>
	/// Represents a lexigraphical comparer for 2-dimensional points.
	/// </summary>
	public class Point2DLexigraphicalComparer
		: IComparer<PointF>
		, IComparer<Point>
	{
		static Point2DLexigraphicalComparer()
		{
			Instance = new Point2DLexigraphicalComparer();
		}

		/// <summary>
		/// Initializes a new instance of <see cref="Point2DLexigraphicalComparer"/> class.
		/// </summary>
		protected Point2DLexigraphicalComparer()
		{
		}

		/// <summary>
		/// Gets the singelton instance of <see cref="Point2DLexigraphicalComparer"/> class.
		/// </summary>
		public static Point2DLexigraphicalComparer Instance { get; private set; }

		#region IComparer<PointF> Members

		/// <summary>
		/// Compares two objects and returns a value indicating whether one is less than, equal to, or greater than the other.
		/// </summary>
		/// <param name="p1">The first <see cref="PointF"/> to compare.</param>
		/// <param name="p2">The second <see cref="PointF"/> to compare.</param>
		/// <returns>
		/// Less than zero <paramref name="p1"/> is less than <paramref name="p2"/>.
		/// Zero <paramref name="p1"/> equals <paramref name="p2"/>.
		/// Greater than zero <paramref name="p1"/> is greater than <paramref name="p2"/>.
		/// </returns>
		public int Compare(PointF p1, PointF p2)
		{
			return (p1.Y > p2.Y) ? 1 : ((p1.Y == p2.Y) ? 0 : -1);
		}

		#endregion

		#region IComparer<Point> Members

		/// <summary>
		/// Compares two objects and returns a value indicating whether one is less than, equal to, or greater than the other.
		/// </summary>
		/// <param name="p1">The first <see cref="PointF"/> to compare.</param>
		/// <param name="p2">The second <see cref="PointF"/> to compare.</param>
		/// <returns>
		/// Less than zero <paramref name="p1"/> is less than <paramref name="p2"/>.
		/// Zero <paramref name="p1"/> equals <paramref name="p2"/>.
		/// Greater than zero <paramref name="p1"/> is greater than <paramref name="p2"/>.
		/// </returns>
		public int Compare(Point p1, Point p2)
		{
			return (p1.Y > p2.Y) ? 1 : ((p1.Y == p2.Y) ? 0 : -1);
		}

		#endregion
	}
}
