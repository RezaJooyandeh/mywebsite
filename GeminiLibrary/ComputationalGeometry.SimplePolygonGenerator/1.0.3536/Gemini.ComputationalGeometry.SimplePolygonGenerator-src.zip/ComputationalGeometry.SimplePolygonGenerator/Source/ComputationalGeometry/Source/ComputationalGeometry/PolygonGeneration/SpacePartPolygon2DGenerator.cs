﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Runtime.Serialization;

namespace Gemini.ComputationalGeometry.PolygonGeneration
{
	public class SpacePartPolygon2DGenerator: RandomPolygon2DGenerator
	{
		public static SimplePolygon2D Generate(int vertexCount, RectangleF region)
		{
			return Generate(vertexCount, region, null);
		}
		
		public static SimplePolygon2D Generate(int vertexCount, RectangleF region, Random randomGenerator)
		{
			if (randomGenerator == null)
				randomGenerator = DefaultRandomGenerator;

			List<PointF> points = GeneratePointSet(vertexCount, region, randomGenerator);

			return Generate(points, randomGenerator);
		}

		public static SimplePolygon2D Generate(IList<PointF> pointSet)
		{
			return Generate(pointSet, null);
		}

		public static SimplePolygon2D Generate(IList<PointF> pointSet, Random randomGenerator)
		{
			if (randomGenerator == null)
				randomGenerator = DefaultRandomGenerator;

			int vertexCount = pointSet.Count;

			int i = randomGenerator.Next(0, vertexCount);
			PointF p1 = pointSet[i];
			pointSet.RemoveAt(i);

			int j = randomGenerator.Next(0, vertexCount - 1);
			PointF p2 = pointSet[j];
			pointSet.RemoveAt(j);

			List<PointF> part1;
			List<PointF> part2;

			DivideSpace(pointSet, new LineSegment2D(p1, p2), out part1, out part2);

			List<PointF> list1 = PartitionSpace(p1, p2, part1, randomGenerator);
			List<PointF> list2 = PartitionSpace(p2, p1, part2, randomGenerator);
			list1.RemoveAt(list1.Count - 1);
			list2.RemoveAt(list2.Count - 1);

			List<PointF> vertices = new List<PointF>(vertexCount);
			vertices.AddRange(list1);
			vertices.AddRange(list2);

			return new SimplePolygon2D(vertices);
		}

		protected static List<PointF> PartitionSpace(PointF p1, PointF p2, IList<PointF> pointSet, Random randomGenerator)
		{
			List<PointF> retVal = new List<PointF>();
			int count = pointSet.Count;
			if (count == 0)
			{
				retVal.Add(p1);
				/*
				if (count > 0)
				{
					if (p1.X == p2.X)
					{
						int s = Math.Sign(p1.Y - p2.Y);
						retVal.AddRange(pointSet.OrderByDescending(q => q.Y * s));
					}
					else if (p1.Y == p2.Y)
					{
						int s = Math.Sign(p1.X - p2.X);
						retVal.AddRange(pointSet.OrderByDescending(q => q.X * s));
					}
					else
					{
						int s = Math.Sign(p1.X - p2.X);
						double m = (p1.Y - p2.Y) / (p1.X - p2.X);
						double b = -m * p1.X + p1.Y;

						var query = from q in pointSet
									orderby s * (m * q.Y + q.X - m * b) / (m * m + 1) descending
									select q;
						retVal.AddRange(query);
					}
				}
				//*/
				retVal.Add(p2);
				return retVal;
			}

			int i = randomGenerator.Next(0, count);
			PointF point2_2 = pointSet[i];
			pointSet.RemoveAt(i);
			LineSegment2D segment = new LineSegment2D(p1, p2);
			float f = (float)randomGenerator.NextDouble();
			f *= Math.Abs(p2.X - p1.X);
			f += Math.Min(p2.X, p1.X);
			PointF point2_3 = segment.CalculateXBasedImage(f);

			LineSegment2D segment2_1 = null;

			switch (segment.Orientation(point2_2))
			{
				case 2: // '\002'
					segment2_1 = new LineSegment2D(point2_3, point2_2);
					break;

				case 3: // '\003'
					segment2_1 = new LineSegment2D(point2_2, point2_3);
					break;

				case 1: // '\001'
				default:
					Console.WriteLine((new StringBuilder()).Append("Something's wrong sf_sl: ").Append(segment.ToString()).Append(point2_2.ToString()).Append(" ").Append(count).ToString());
					break;
			}

			List<PointF> vector1;
			List<PointF> vector2;
			DivideSpace(pointSet, segment2_1, out vector1, out vector2);
			List<PointF> point2list = PartitionSpace(p1, point2_2, vector1, randomGenerator);
			List<PointF> point2list1 = PartitionSpace(point2_2, p2, vector2, randomGenerator);
			point2list.RemoveAt(point2list.Count - 1);
			retVal.AddRange(point2list);
			retVal.AddRange(point2list1);
			return retVal;
		}
	}
}
