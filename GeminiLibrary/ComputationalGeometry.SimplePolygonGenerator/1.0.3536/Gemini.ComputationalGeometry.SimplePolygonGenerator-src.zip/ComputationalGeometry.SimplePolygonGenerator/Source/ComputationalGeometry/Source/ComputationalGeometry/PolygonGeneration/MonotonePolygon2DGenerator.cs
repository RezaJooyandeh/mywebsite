﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Diagnostics;

namespace Gemini.ComputationalGeometry.PolygonGeneration
{
	public class MonotonePolygon2DGenerator : RandomPolygon2DGenerator
	{
		public static SimplePolygon2D Generate(int vertexCount, RectangleF region)
		{
			return Generate(vertexCount, region, null);
		}

		public static SimplePolygon2D Generate(int vertexCount, RectangleF region, Random randomGenerator)
		{
			if (randomGenerator == null)
				randomGenerator = DefaultRandomGenerator;

			List<PointF> points = GeneratePointSet(vertexCount, region, randomGenerator);

			return Generate(points, randomGenerator);
		}

		public static SimplePolygon2D Generate(IList<PointF> pointSet)
		{
			return Generate(pointSet, null);
		}

		public static SimplePolygon2D Generate(IList<PointF> pointSet, Random randomGenerator)
		{
			if (randomGenerator == null)
				randomGenerator = DefaultRandomGenerator;

			int vertexCount = pointSet.Count;
			PointF topPoint = new PointF(0, float.MaxValue);
			PointF bottomPoint = new PointF(0, float.MinValue);
			int topPointIndex = -1;
			int bottomPointIndex = -1;

			for (int i = 0; i < vertexCount; i++)
			{
				PointF curPoint = pointSet[i];
				if (topPoint.Y > curPoint.Y)
				{
					topPoint = curPoint;
					topPointIndex = i;
				}

				if (bottomPoint.Y < curPoint.Y)
				{
					bottomPoint = curPoint;
					bottomPointIndex = i;
				}
			}

			Debug.Assert(topPointIndex != -1);
			Debug.Assert(bottomPointIndex != -1);

			pointSet.RemoveAt(topPointIndex);
			if (topPointIndex < bottomPointIndex)
				pointSet.RemoveAt(bottomPointIndex - 1);
			else if (topPointIndex > bottomPointIndex)
				pointSet.RemoveAt(bottomPointIndex);
			else
				Debug.Assert(topPointIndex != bottomPointIndex);

			LineSegment2D segment = new LineSegment2D(topPoint, bottomPoint);

			List<PointF> part1;
			List<PointF> part2;

			DivideSpace(pointSet, segment, out part1, out part2);

			part1.Sort(Point2DLexigraphicalComparer.Instance);
			part2.Sort(Point2DLexigraphicalComparer.Instance);

			List<PointF> vertexSet = new List<PointF>(vertexCount);
			vertexSet.Add(topPoint);
			vertexSet.AddRange(part1);
			vertexSet.Add(bottomPoint);
			vertexSet.AddRange(part2);

			return new SimplePolygon2D(vertexSet);
		}
	}
}
