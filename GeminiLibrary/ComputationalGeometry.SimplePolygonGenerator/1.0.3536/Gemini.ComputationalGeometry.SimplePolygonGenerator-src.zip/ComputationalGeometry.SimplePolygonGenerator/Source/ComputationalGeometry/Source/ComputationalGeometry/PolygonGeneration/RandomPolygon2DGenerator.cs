﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization;
using System.Diagnostics;

namespace Gemini.ComputationalGeometry.PolygonGeneration
{
	public class RandomPolygon2DGenerator
	{
		/// <summary>
		/// Generates a set of random points in a given range.
		/// </summary>
		/// <param name="pointCount">The number of points to be generated.</param>
		/// <param name="region">The range in which the points are going to be generated.</param>
		/// <returns>The generated points.</returns>
		protected static List<PointF> GeneratePointSet(int pointCount, RectangleF region)
		{
			return GeneratePointSet(pointCount, region, DefaultRandomGenerator);
		}

		/// <summary>
		/// Generates a set of random points in a given range.
		/// </summary>
		/// <param name="pointCount">The number of points to be generated.</param>
		/// <param name="region">The range in which the points are going to be generated.</param>
		/// <param name="randomGenerator">The random generator which is used to generate points.</param>
		/// <returns>The generated points.</returns>
		protected static List<PointF> GeneratePointSet(int pointCount, RectangleF region, Random randomGenerator)
		{
			if (randomGenerator == null)
				randomGenerator = DefaultRandomGenerator;

			List<PointF> points = new List<PointF>(pointCount);

			for (int i = 0; i < pointCount; )
			{
				bool isValid = true;
				PointF point = new PointF(
					(float)(randomGenerator.NextDouble() * region.Width + region.Left),
					(float)(randomGenerator.NextDouble() * region.Height + region.Top));

				for (int j = 0; j < i; j++)
				{
					if (point.Equals(points[j]))
					{
						isValid = false;
						break;
					}

					for (int k = j + 1; k < i; k++)
					{
						int orientation = point.Orientation(points[j], points[k]);
						if ((orientation != 2) && (orientation != 3))
						{
							isValid = false;
							j = i;
							break;
						}
					}
				}

				if (isValid)
				{
					points.Add(point);
					i++;
				}
			}

			return points;
		}

		protected static void DivideSpace(IList<PointF> pointSet, LineSegment2D segment, out List<PointF> part1, out List<PointF> part2)
		{
			part1 = new List<PointF>();
			part2 = new List<PointF>();
			int count = pointSet.Count;
			for (int i = 0; i < count; i++)
			{
				PointF point2 = pointSet[i];
				switch (segment.Orientation(point2))
				{
					case 2: // '\002'
						part1.Add(point2);
						break;

					case 3: // '\003'
						part2.Add(point2);
						break;

					case 1: // '\001'
						part1.Add(point2);
						break;

					default:
						string msg = (new StringBuilder()).Append("Something's wrong: ").Append(segment.ToString()).Append(point2.ToString()).ToString();
						Debug.Assert(false, msg);
						Console.WriteLine(msg);
						break;
				}
			}
		}

		protected static Random DefaultRandomGenerator = new Random();
	}
}
