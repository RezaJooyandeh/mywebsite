﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gemini.ComputationalGeometry.PolygonGeneration
{
	public enum Polygon2DGeneratorType
	{
		Unknown,
		SpacePart,
		Monotone
	}
}
