﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Gemini.ComputationalGeometry
{
	/// <summary>
	/// Represents a 2-dimentional line segment.
	/// </summary>
	public class LineSegment2D
	{
		/// <summary>
		/// Initializes a new instance of <see cref="LineSegment2D"/> class.
		/// </summary>
		public LineSegment2D()
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="LineSegment2D"/> class using the specified endpoints.
		/// </summary>
		/// <param name="p1">The source point of the line segment.</param>
		/// <param name="p2">The target point of the line segment.</param>
		public LineSegment2D(PointF p1, PointF p2)
		{
			source = p1;
			target = p2;
		}

		/// <summary>
		/// Gets/sets the source point of the line segment.
		/// </summary>
		public PointF Source
		{
			get { return source; }
			set { source = value; }
		}

		/// <summary>
		/// Gets/sets the target point of the line segment.
		/// </summary>
		public PointF Target
		{
			get { return target; }
			set { target = value; }
		}

		/// <summary>
		/// Calculates the point on the line whose first cordinate is <paramref name="x"/>.
		/// </summary>
		/// <param name="x">The first cordinate of the calculating point.</param>
		/// <returns>The point on the line whose first cordinate is <paramref name="x"/> if there is any; <see cref="PointF.Empty"/> otherwise.</returns>
		public PointF CalculateXBasedImage(float x)
		{
			if (IsVertical)
				if (x == source.X)
					return new PointF(x, (1.0F / 0.0F));
				else
					return PointF.Empty;
			double m = (double)(source.Y - target.Y) / (double)(source.X - target.X);
			double h = (double)source.Y - m * (double)source.X;
			PointF point2 = new PointF(x, (float)(m * x + h));

			return point2;
		}

		/// <summary>
		/// Gets the value indicating if the line segment is vertical.
		/// </summary>
		public bool IsVertical
		{
			get { return source.X == target.X; }
		}

		/// <summary>
		/// Gets the value indicating if the line segment is horizontal.
		/// </summary>
		public bool IsHorizontal
		{
			get { return source.Y == target.Y; }
		}

		public int Orientation(PointF point2)
		{
			return point2.Orientation(source, target);
		}

		private PointF source;
		private PointF target;
	}
}
