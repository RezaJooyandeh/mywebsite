﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections.ObjectModel;
using System.Runtime.Serialization;

namespace Gemini.ComputationalGeometry
{
	/// <summary>
	/// Represents a 2-dimentional simple polygon.
	/// </summary>
	[Serializable]
	public class SimplePolygon2D : ISerializable, ICloneable
	{
		#region .ctor

		/// <summary>
		/// Initializes a new instance of <see cref="SimplePolygon2D"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertices">The vertices of the current simple polygon.</param>
		public SimplePolygon2D(IList<PointF> vertices)
		{
			Vertices = new ReadOnlyCollection<PointF>(new List<PointF>(vertices));
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="SimplePolygon2D"/> class with serialized data.
		/// </summary>
		/// <param name="info">The <see cref="SerializationInfo"/> that holds the serialized object data about the simple polygon.</param>
		/// <param name="context">The <see cref="StreamingContext"/> that contains contextual information about the source or destination.</param>
		protected SimplePolygon2D(SerializationInfo info, StreamingContext context)
		{
			Vertices = (IList<PointF>)info.GetValue("Vertices", typeof(ReadOnlyCollection<PointF>));
		}

		#endregion

		#region ISerializable Members

		/// <summary>
		/// Sets the <see cref="SerializationInfo"/> with information about the simple polygon.
		/// </summary>
		/// <param name="info">The <see cref="SerializationInfo"/> that holds the serialized object data about the simple polygon.</param>
		/// <param name="context">The <see cref="StreamingContext"/> that contains contextual information about the source or destination.</param>
		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("Vertices", Vertices);
		}

		#endregion

		#region Clone

		/// <summary>
		/// Creates a new polygon that is a copy of the current polygon.
		/// </summary>
		/// <returns>A new simple polygon that is a copy of this instance.</returns>
		public SimplePolygon2D Clone()
		{
			return new SimplePolygon2D(this.Vertices);
		}

		#region ICloneable Members

		/// <summary>
		/// Creates a new polygon that is a copy of the current polygon.
		/// </summary>
		/// <returns>A new simple polygon that is a copy of this instance.</returns>
		object ICloneable.Clone()
		{
			return Clone();
		}

		#endregion

		#endregion

		/// <summary>
		/// Gets the vertecies of the current polygon.
		/// </summary>
		public IList<PointF> Vertices { get; private set; }

		public IList<PointF> FindCooperativeGuardSet()
		{
			List<Vertex> vertices = new List<Vertex>(Vertices.Count);
			int i = 0;
			foreach (PointF p in Vertices)
				vertices.Add(new Vertex() { PointF = p, Color = VertexColor.Unknown, Index = i++ });

			IList<Trainagle> triangules = Triangulate(vertices);
			ColorizeVertices(triangules);
			IList<Face> faces;
			IList<PointF> candidtaeGuards = FindCandidateCooperativeGuardSet(triangules, out faces);
			IList<PointF> cooperativeGuardSet = OptimizeCooperativeGuardSet(candidtaeGuards, faces);
			return cooperativeGuardSet;
		}

		private IList<Trainagle> Triangulate(IList<Vertex> vertices)
		{
			throw new NotImplementedException();
		}

		private void ColorizeVertices(IList<Trainagle> triangules)
		{
			Trainagle prevTrain = null;
			foreach (Trainagle t in triangules)
			{
				if (prevTrain == null)
				{
					t.V1.Color = VertexColor.One;
					t.V2.Color = VertexColor.Two;
					t.V3.Color = VertexColor.Three;
				}
				else
				{
					if (t.V1.Color == VertexColor.Unknown)
						t.V1.Color = VertexColor.All ^ t.V2.Color ^ t.V3.Color;
					else if (t.V2.Color == VertexColor.Unknown)
						t.V2.Color = VertexColor.All ^ t.V3.Color ^ t.V1.Color;
					else
						t.V3.Color = VertexColor.All ^ t.V1.Color ^ t.V2.Color;
				}

				prevTrain = t;
			}
		}

		private IList<PointF> FindCandidateCooperativeGuardSet(IList<Trainagle> triangules, out IList<Face> faces)
		{
			int count = triangules.Count;
			faces = new List<Face>(count);
			for (int i = 0; i < count; i++)
			{
				Trainagle t = triangules[i];

				Vertex c2;
				Vertex c3;
				if (t.V1.Color == VertexColor.Two)
				{
					c2 = t.V1;
					if (t.V2.Color == VertexColor.Three)
						c3 = t.V2;
					else
						c3 = t.V3;
				}
				else if (t.V1.Color == VertexColor.Three)
				{
					c3 = t.V1;
					if (t.V2.Color == VertexColor.Two)
						c2 = t.V2;
					else
						c2 = t.V3;
				}
				else
				{
					if (t.V2.Color == VertexColor.Two)
					{
						c2 = t.V2;
						c3 = t.V3;
					}
					else
					{
						c2 = t.V3;
						c3 = t.V2;
					}
				}

				int delta = Math.Abs(c2.Index - c3.Index);
				if ((delta == 1) || (delta == count - 1))
				{
					Quadrilateral q = new Quadrilateral() { V1 = t.V1, V2 = t.V2, V3 = t.V3 };
					Trainagle next = triangules[i + 1];

				}
				else
					faces.Add(t);
			}

			return null;
		}

		private IList<PointF> OptimizeCooperativeGuardSet(IList<PointF> candidtaeGuards, IList<Face> faces)
		{
			throw new NotImplementedException();
		}

		enum FaceColor { Unknown, Plus, Minus };
		[Flags]
		enum VertexColor
		{
			Unknown = 0,
			One = 1,
			Two = 2,
			Three = 4,
			All = 7
		};

		abstract class Face
		{
			public FaceColor Color { get; set; }
		}

		class Trainagle : Face
		{
			public Vertex V1 { get; set; }
			public Vertex V2 { get; set; }
			public Vertex V3 { get; set; }
		}

		class Quadrilateral : Face
		{
			public Vertex V1 { get; set; }
			public Vertex V2 { get; set; }
			public Vertex V3 { get; set; }
			public Vertex V4 { get; set; }
		}

		class Vertex
		{
			public PointF PointF { get; set; }
			public VertexColor Color { get; set; }
			public int Index { get; set; }
		}
	}
}
