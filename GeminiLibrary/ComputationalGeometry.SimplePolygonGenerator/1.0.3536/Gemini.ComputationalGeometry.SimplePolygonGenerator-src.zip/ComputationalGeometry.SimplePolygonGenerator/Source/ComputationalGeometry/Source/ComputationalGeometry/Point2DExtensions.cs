﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace Gemini.ComputationalGeometry
{
	public static class Point2DExtensions
	{
		public static int Orientation(this PointF self, PointF p1, PointF p2)
		{
			byte byte0;
			if (p1.Equals(p2))
			{
				if (self.Equals(p1))
					byte0 = 1;
				else
					byte0 = 4;
			}
			else
			{
				double d = (p1.X - self.X) * (p2.Y - self.Y) - (p1.Y - self.Y) * (p2.X - self.X);
				double d1 = (Math.Abs(p1.X) + Math.Abs(self.X)) * (Math.Abs(p2.Y) + Math.Abs(self.Y)) + (Math.Abs(p1.Y) + Math.Abs(self.Y)) * (Math.Abs(p2.X) + Math.Abs(self.X));
				if (Math.Abs(d) <= d1 * 2.0000000233721948E-007D)
					byte0 = 1;
				else
					if (d < 0.0D)
						byte0 = 3;
					else
						byte0 = 2;
			}
			return byte0;
		}
	}
}
