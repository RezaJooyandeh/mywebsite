﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Runtime.Serialization;
using Gemini.ComputationalGeometry.PolygonGeneration;

namespace Gemini.ComputationalGeometry.DataSet
{
	/// <summary>
	/// Represents the a set of 2-dimentional simple monotone polygons.
	/// </summary>
	[Serializable]
	public class MonotonePolygon2DSet : RandomPolygon2DSetBase
	{
		#region .ctor

		/// <summary>
		/// Initializes a new instance of <see cref="MonotonePolygon2DSet"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		public MonotonePolygon2DSet(int vertexCount)
			: base(vertexCount)
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="MonotonePolygon2DSet"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		public MonotonePolygon2DSet(int vertexCount, int setSize)
			: base(vertexCount, setSize)
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="MonotonePolygon2DSet"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		/// <param name="region">The region from which the vertices are selected.</param>
		public MonotonePolygon2DSet(int vertexCount, int setSize, RectangleF region)
			: base(vertexCount, setSize, region)
		{
		}

		/// <summary>
		/// Initializes a new instance of <see cref="MonotonePolygon2DSet"/> class using the specified vertices.
		/// </summary>
		/// <param name="vertexCount">The number of vertices of each set member.</param>
		/// <param name="setSize">The number of the members of the set.</param>
		/// <param name="region">The region from which the vertices are selected.</param>
		/// <param name="seed">The initializing random seed for generating polygons.</param>
		public MonotonePolygon2DSet(int vertexCount, int setSize, RectangleF region, int seed)
			: base(vertexCount, setSize, region, seed)
		{
		}

		/// <summary>
		/// Initializes a new instance of the <see cref="MonotonePolygon2DSet"/> class with serialized data.
		/// </summary>
		/// <param name="info">The <see cref="SerializationInfo"/> that holds the serialized object data about the random polygon set.</param>
		/// <param name="context">The <see cref="StreamingContext"/> that contains contextual information about the source or destination.</param>
		protected MonotonePolygon2DSet(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{
		}

		#endregion

		/// <summary>
		/// Generates a monotone <see cref="SimplePolygon2D"/>.
		/// </summary>
		/// <param name="vertexCount">The number of the vertices of the generating polygon.</param>
		/// <param name="region">The region in which the vertices are selecting.</param>
		/// <param name="randomGenerator">The random generator which is used for generating set members.</param>
		/// <returns>The generated polygon.</returns>
		protected override SimplePolygon2D Generate(int vertexCount, RectangleF region, Random randomGenerator)
		{
			return MonotonePolygon2DGenerator.Generate(vertexCount, region, randomGenerator);
		}
	}
}
